window.ecwid_states_data.loaded({
    "AE": [{
        "c": "AD",
        "n": "Abu Dhabi"
    }, {
        "c": "AJ",
        "n": "Ajman"
    }, {
        "c": "DB",
        "n": "Dubai"
    }, {
        "c": "FJ",
        "n": "Fujairah"
    }, {
        "c": "RK",
        "n": "Ras al-Khaimah"
    }, {
        "c": "SH",
        "n": "Sharjah"
    }, {
        "c": "UQ",
        "n": "Umm al-Quwain"
    }],
    "AR": [{
        "c": "C",
        "n": "Ciudad Autónoma de Buenos Aires"
    }, {
        "c": "B",
        "n": "Provincia de Buenos Aires"
    }, {
        "c": "K",
        "n": "Catamarca"
    }, {
        "c": "H",
        "n": "Chaco"
    }, {
        "c": "U",
        "n": "Chubut"
    }, {
        "c": "X",
        "n": "Córdoba"
    }, {
        "c": "W",
        "n": "Corrientes"
    }, {
        "c": "E",
        "n": "Entre Ríos"
    }, {
        "c": "P",
        "n": "Formosa"
    }, {
        "c": "Y",
        "n": "Jujuy"
    }, {
        "c": "L",
        "n": "La Pampa"
    }, {
        "c": "F",
        "n": "La Rioja"
    }, {
        "c": "M",
        "n": "Mendoza"
    }, {
        "c": "N",
        "n": "Misiones"
    }, {
        "c": "Q",
        "n": "Neuquén"
    }, {
        "c": "R",
        "n": "Río Negro"
    }, {
        "c": "A",
        "n": "Salta"
    }, {
        "c": "J",
        "n": "San Juan"
    }, {
        "c": "D",
        "n": "San Luis"
    }, {
        "c": "Z",
        "n": "Santa Cruz"
    }, {
        "c": "S",
        "n": "Santa Fe"
    }, {
        "c": "G",
        "n": "Santiago del Estero"
    }, {
        "c": "V",
        "n": "Tierra del Fuego"
    }, {
        "c": "T",
        "n": "Tucumán"
    }],
    "AT": [{
        "c": "1",
        "n": "Burgenland"
    }, {
        "c": "2",
        "n": "Carinthia"
    }, {
        "c": "3",
        "n": "Lower Austria"
    }, {
        "c": "4",
        "n": "Upper Austria"
    }, {
        "c": "5",
        "n": "Salzburg"
    }, {
        "c": "6",
        "n": "Styria"
    }, {
        "c": "7",
        "n": "Tyrol"
    }, {
        "c": "8",
        "n": "Vorarlberg"
    }, {
        "c": "9",
        "n": "Vienna"
    }],
    "AU": [{
        "c": "ACT",
        "n": "Australian Capital Territory"
    }, {
        "c": "NSW",
        "n": "New South Wales"
    }, {
        "c": "NT",
        "n": "Northern Territory"
    }, {
        "c": "QLD",
        "n": "Queensland"
    }, {
        "c": "SA",
        "n": "South Australia"
    }, {
        "c": "TAS",
        "n": "Tasmania"
    }, {
        "c": "VIC",
        "n": "Victoria"
    }, {
        "c": "WA",
        "n": "Western Australia"
    }],
    "BE": [{
        "c": "ANT",
        "n": "Antwerpen"
    }, {
        "c": "WBR",
        "n": "Brabant Wallon"
    }, {
        "c": "BRU",
        "n": "Brussel - Bruxelles"
    }, {
        "c": "HAI",
        "n": "Hainaut"
    }, {
        "c": "LIE",
        "n": "Liège"
    }, {
        "c": "LIM",
        "n": "Limburg"
    }, {
        "c": "LUX",
        "n": "Luxembourg"
    }, {
        "c": "NAM",
        "n": "Namur"
    }, {
        "c": "OVL",
        "n": "Oost-Vlaanderen"
    }, {
        "c": "VBR",
        "n": "Vlaams-Brabant"
    }, {
        "c": "WVL",
        "n": "West-Vlaanderen"
    }],
    "BO": [{
        "c": "B",
        "n": "El Beni"
    }, {
        "c": "C",
        "n": "Cochabamba"
    }, {
        "c": "H",
        "n": "Chuquisaca"
    }, {
        "c": "L",
        "n": "La Paz"
    }, {
        "c": "N",
        "n": "Pando"
    }, {
        "c": "O",
        "n": "Oruro"
    }, {
        "c": "P",
        "n": "Potosí"
    }, {
        "c": "S",
        "n": "Santa Cruz"
    }, {
        "c": "T",
        "n": "Tarija"
    }],
    "BR": [{
        "c": "AC",
        "n": "Acre"
    }, {
        "c": "AL",
        "n": "Alagoas"
    }, {
        "c": "AP",
        "n": "Amapá"
    }, {
        "c": "AM",
        "n": "Amazonas"
    }, {
        "c": "BA",
        "n": "Bahia"
    }, {
        "c": "CE",
        "n": "Ceará"
    }, {
        "c": "DF",
        "n": "Distrito Federal"
    }, {
        "c": "ES",
        "n": "Espírito Santo"
    }, {
        "c": "GO",
        "n": "Goiás"
    }, {
        "c": "MA",
        "n": "Maranhão"
    }, {
        "c": "MT",
        "n": "Mato Grosso"
    }, {
        "c": "MS",
        "n": "Mato Grosso do Sul"
    }, {
        "c": "MG",
        "n": "Minas Gerais"
    }, {
        "c": "PA",
        "n": "Pará"
    }, {
        "c": "PB",
        "n": "Paraíba"
    }, {
        "c": "PR",
        "n": "Paraná"
    }, {
        "c": "PE",
        "n": "Pernambuco"
    }, {
        "c": "PI",
        "n": "Piauí"
    }, {
        "c": "RJ",
        "n": "Rio de Janeiro"
    }, {
        "c": "RN",
        "n": "Rio Grande do Norte"
    }, {
        "c": "RS",
        "n": "Rio Grande do Sul"
    }, {
        "c": "RO",
        "n": "Rondônia"
    }, {
        "c": "RR",
        "n": "Roraima"
    }, {
        "c": "SC",
        "n": "Santa Catarina"
    }, {
        "c": "SP",
        "n": "São Paulo"
    }, {
        "c": "SE",
        "n": "Sergipe"
    }, {
        "c": "TO",
        "n": "Tocantins"
    }],
    "BS": [{
        "c": "BS-AK",
        "n": "Acklins",
        "lsc": "AK"
    }, {
        "c": "BS-BI",
        "n": "Bimini",
        "lsc": "BI"
    }, {
        "c": "BS-BP",
        "n": "Black Point",
        "lsc": "BP"
    }, {
        "c": "BS-BY",
        "n": "Berry Islands",
        "lsc": "BY"
    }, {
        "c": "BS-CE",
        "n": "Central Eleuthera",
        "lsc": "CE"
    }, {
        "c": "BS-CI",
        "n": "Cat Island",
        "lsc": "CI"
    }, {
        "c": "BS-CK",
        "n": "Crooked Island and Long Cay",
        "lsc": "CK"
    }, {
        "c": "BS-CO",
        "n": "Central Abaco",
        "lsc": "CO"
    }, {
        "c": "BS-CS",
        "n": "Central Andros",
        "lsc": "CS"
    }, {
        "c": "BS-EG",
        "n": "East Grand Bahama",
        "lsc": "EG"
    }, {
        "c": "BS-EX",
        "n": "Exuma",
        "lsc": "EX"
    }, {
        "c": "BS-FP",
        "n": "City of Freeport",
        "lsc": "FP"
    }, {
        "c": "BS-GC",
        "n": "Grand Cay",
        "lsc": "GC"
    }, {
        "c": "BS-HI",
        "n": "Harbour Island",
        "lsc": "HI"
    }, {
        "c": "BS-HT",
        "n": "Hope Town",
        "lsc": "HT"
    }, {
        "c": "BS-IN",
        "n": "Inagua",
        "lsc": "IN"
    }, {
        "c": "BS-LI",
        "n": "Long Island",
        "lsc": "LI"
    }, {
        "c": "BS-MC",
        "n": "Mangrove Cay",
        "lsc": "MC"
    }, {
        "c": "BS-MG",
        "n": "Mayaguana",
        "lsc": "MG"
    }, {
        "c": "BS-MI",
        "n": "Moore\u0027s Island",
        "lsc": "MI"
    }, {
        "c": "BS-NE",
        "n": "North Eleuthera",
        "lsc": "NE"
    }, {
        "c": "BS-NO",
        "n": "North Abaco",
        "lsc": "NO"
    }, {
        "c": "BS-NP",
        "n": "New Providence",
        "lsc": "NP"
    }, {
        "c": "BS-NS",
        "n": "North Andros",
        "lsc": "NS"
    }, {
        "c": "BS-RC",
        "n": "Rum Cay",
        "lsc": "RC"
    }, {
        "c": "BS-RI",
        "n": "Ragged Island",
        "lsc": "RI"
    }, {
        "c": "BS-SA",
        "n": "South Andros",
        "lsc": "SA"
    }, {
        "c": "BS-SE",
        "n": "South Eleuthera",
        "lsc": "SE"
    }, {
        "c": "BS-SO",
        "n": "South Abaco",
        "lsc": "SO"
    }, {
        "c": "BS-SS",
        "n": "San Salvador",
        "lsc": "SS"
    }, {
        "c": "BS-SW",
        "n": "Spanish Wells",
        "lsc": "SW"
    }, {
        "c": "BS-WG",
        "n": "West Grand Bahama",
        "lsc": "WG"
    }],
    "BQ": [{
        "c": "BQ-BO",
        "n": "Bonaire",
        "lsc": "BO"
    }, {
        "c": "BQ-SE",
        "n": "Sint Eustatius",
        "lsc": "SE"
    }, {
        "c": "BQ-SA",
        "n": "Saba",
        "lsc": "SA"
    }],
    "CA": [{
        "c": "AB",
        "n": "Alberta"
    }, {
        "c": "BC",
        "n": "British Columbia"
    }, {
        "c": "MB",
        "n": "Manitoba"
    }, {
        "c": "NB",
        "n": "New Brunswick"
    }, {
        "c": "NL",
        "n": "Newfoundland/Labrador"
    }, {
        "c": "NT",
        "n": "Northwest Territories"
    }, {
        "c": "NS",
        "n": "Nova Scotia"
    }, {
        "c": "NU",
        "n": "Nunavut"
    }, {
        "c": "ON",
        "n": "Ontario"
    }, {
        "c": "PE",
        "n": "Prince Edward Island"
    }, {
        "c": "QC",
        "n": "Quebec"
    }, {
        "c": "SK",
        "n": "Saskatchewan"
    }, {
        "c": "YT",
        "n": "Yukon"
    }],
    "CH": [{
        "c": "AG",
        "n": "Aargau"
    }, {
        "c": "AI",
        "n": "Appenzell Innerrhoden"
    }, {
        "c": "AR",
        "n": "Appenzell Ausserrhoden"
    }, {
        "c": "BE",
        "n": "Bern"
    }, {
        "c": "BL",
        "n": "Basel-Landschaft"
    }, {
        "c": "BS",
        "n": "Basel-Stadt"
    }, {
        "c": "FR",
        "n": "Fribourg"
    }, {
        "c": "GE",
        "n": "Geneva"
    }, {
        "c": "GL",
        "n": "Glarus"
    }, {
        "c": "GR",
        "n": "Graubünden"
    }, {
        "c": "JU",
        "n": "Jura"
    }, {
        "c": "LU",
        "n": "Lucerne"
    }, {
        "c": "NE",
        "n": "Neuchâtel"
    }, {
        "c": "NW",
        "n": "Nidwalden"
    }, {
        "c": "OW",
        "n": "Obwalden"
    }, {
        "c": "SG",
        "n": "St. Gallen"
    }, {
        "c": "SH",
        "n": "Schaffhausen"
    }, {
        "c": "SO",
        "n": "Solothurn"
    }, {
        "c": "SZ",
        "n": "Schwyz"
    }, {
        "c": "TG",
        "n": "Thurgau"
    }, {
        "c": "TI",
        "n": "Ticino"
    }, {
        "c": "UR",
        "n": "Uri"
    }, {
        "c": "VD",
        "n": "Vaud"
    }, {
        "c": "VS",
        "n": "Valais"
    }, {
        "c": "ZG",
        "n": "Zug"
    }, {
        "c": "ZH",
        "n": "Zürich"
    }],
    "CL": [{
        "c": "AP",
        "n": "Arica y Parinacota"
    }, {
        "c": "AN",
        "n": "Antofagasta"
    }, {
        "c": "AT",
        "n": "Atacama"
    }, {
        "c": "AY",
        "n": "Aysén del General Carlos Ibáñez del Campo"
    }, {
        "c": "BB",
        "n": "Bío Bío"
    }, {
        "c": "CO",
        "n": "Coquimbo"
    }, {
        "c": "LA",
        "n": "La Araucanía"
    }, {
        "c": "LG",
        "n": "Libertador General Bernardo O\u0027Higgins"
    }, {
        "c": "LL",
        "n": "Los Lagos"
    }, {
        "c": "LR",
        "n": "Los Ríos"
    }, {
        "c": "MA",
        "n": "Magallanes y la Antártica Chilena"
    }, {
        "c": "MU",
        "n": "Maule"
    }, {
        "c": "NB",
        "n": "Ñuble"
    }, {
        "c": "MS",
        "n": "Metropolitana de Santiago"
    }, {
        "c": "TA",
        "n": "Tarapacá"
    }, {
        "c": "VA",
        "n": "Valparaíso"
    }],
    "CM": [{
        "c": "AD",
        "n": "Adamaoua"
    }, {
        "c": "CE",
        "n": "Centre"
    }, {
        "c": "ES",
        "n": "East"
    }, {
        "c": "EN",
        "n": "Far North"
    }, {
        "c": "LT",
        "n": "Littoral"
    }, {
        "c": "NO",
        "n": "North"
    }, {
        "c": "NW",
        "n": "North-West"
    }, {
        "c": "SU",
        "n": "South"
    }, {
        "c": "SW",
        "n": "South-West"
    }, {
        "c": "OU",
        "n": "West"
    }],
    "CO": [{
        "c": "DC",
        "n": "Distrito Capital de Bogotá"
    }, {
        "c": "AMA",
        "n": "Amazonas"
    }, {
        "c": "ANT",
        "n": "Antioquia"
    }, {
        "c": "ARA",
        "n": "Arauca"
    }, {
        "c": "ATL",
        "n": "Atlántico"
    }, {
        "c": "BOL",
        "n": "Bolívar"
    }, {
        "c": "BOY",
        "n": "Boyacá"
    }, {
        "c": "CAL",
        "n": "Caldas"
    }, {
        "c": "CAQ",
        "n": "Caquetá"
    }, {
        "c": "CAS",
        "n": "Casanare"
    }, {
        "c": "CAU",
        "n": "Cauca"
    }, {
        "c": "CES",
        "n": "Cesar"
    }, {
        "c": "COR",
        "n": "Córdoba"
    }, {
        "c": "CUN",
        "n": "Cundinamarca"
    }, {
        "c": "CHO",
        "n": "Chocó"
    }, {
        "c": "GUA",
        "n": "Guainía"
    }, {
        "c": "GUV",
        "n": "Guaviare"
    }, {
        "c": "HUI",
        "n": "Huila"
    }, {
        "c": "LAG",
        "n": "La Guajira"
    }, {
        "c": "MAG",
        "n": "Magdalena"
    }, {
        "c": "MET",
        "n": "Meta"
    }, {
        "c": "NAR",
        "n": "Nariño"
    }, {
        "c": "NSA",
        "n": "Norte de Santander"
    }, {
        "c": "PUT",
        "n": "Putumayo"
    }, {
        "c": "QUI",
        "n": "Quindío"
    }, {
        "c": "RIS",
        "n": "Risaralda"
    }, {
        "c": "SAP",
        "n": "San Andrés, Providencia y Santa Catalina"
    }, {
        "c": "SAN",
        "n": "Santander"
    }, {
        "c": "SUC",
        "n": "Sucre"
    }, {
        "c": "TOL",
        "n": "Tolima"
    }, {
        "c": "VAC",
        "n": "Valle del Cauca"
    }, {
        "c": "VAU",
        "n": "Vaupés"
    }, {
        "c": "VID",
        "n": "Vichada"
    }],
    "CN": [{
        "c": "11",
        "n": "Beijing"
    }, {
        "c": "12",
        "n": "Tianjin"
    }, {
        "c": "13",
        "n": "Hebei"
    }, {
        "c": "14",
        "n": "Shanxi"
    }, {
        "c": "15",
        "n": "Nei Mongol (Inner Mongolia)"
    }, {
        "c": "21",
        "n": "Liaoning"
    }, {
        "c": "22",
        "n": "Jilin"
    }, {
        "c": "23",
        "n": "Heilongjiang"
    }, {
        "c": "31",
        "n": "Shanghai"
    }, {
        "c": "32",
        "n": "Jiangsu"
    }, {
        "c": "33",
        "n": "Zhejiang"
    }, {
        "c": "34",
        "n": "Anhui"
    }, {
        "c": "35",
        "n": "Fujian"
    }, {
        "c": "36",
        "n": "Jiangxi"
    }, {
        "c": "37",
        "n": "Shandong"
    }, {
        "c": "41",
        "n": "Henan"
    }, {
        "c": "42",
        "n": "Hubei"
    }, {
        "c": "43",
        "n": "Hunan"
    }, {
        "c": "44",
        "n": "Guangdong"
    }, {
        "c": "45",
        "n": "Guangxi"
    }, {
        "c": "46",
        "n": "Hainan"
    }, {
        "c": "50",
        "n": "Chongqing"
    }, {
        "c": "51",
        "n": "Sichuan"
    }, {
        "c": "52",
        "n": "Guizhou"
    }, {
        "c": "53",
        "n": "Yunnan"
    }, {
        "c": "54",
        "n": "Xizang (Tibet)"
    }, {
        "c": "61",
        "n": "Shaanxi"
    }, {
        "c": "62",
        "n": "Gansu"
    }, {
        "c": "63",
        "n": "Qinghai"
    }, {
        "c": "64",
        "n": "Ningxia"
    }, {
        "c": "65",
        "n": "Xinjiang"
    }, {
        "c": "71",
        "n": "Taiwan"
    }, {
        "c": "91",
        "n": "Hong Kong (Xianggang)"
    }, {
        "c": "92",
        "n": "Macao (Aomen)"
    }],
    "CR": [{
        "c": "CR-A",
        "n": "Alajuela",
        "lsc": "A"
    }, {
        "c": "CR-C",
        "n": "Cartago",
        "lsc": "C"
    }, {
        "c": "CR-G",
        "n": "Guanacaste",
        "lsc": "G"
    }, {
        "c": "CR-H",
        "n": "Heredia",
        "lsc": "H"
    }, {
        "c": "CR-L",
        "n": "Limón",
        "lsc": "L"
    }, {
        "c": "CR-P",
        "n": "Puntarenas",
        "lsc": "P"
    }, {
        "c": "CR-SJ",
        "n": "San José",
        "lsc": "SJ"
    }],
    "DE": [{
        "c": "BW",
        "n": "Baden-Wurttemberg"
    }, {
        "c": "BY",
        "n": "Bavaria"
    }, {
        "c": "BE",
        "n": "Berlin"
    }, {
        "c": "BR",
        "n": "Brandenburg"
    }, {
        "c": "HB",
        "n": "Bremen"
    }, {
        "c": "HH",
        "n": "Hamburg"
    }, {
        "c": "HE",
        "n": "Hesse"
    }, {
        "c": "MV",
        "n": "Mecklenburg-Western Pomerania"
    }, {
        "c": "NI",
        "n": "Lower Saxony"
    }, {
        "c": "NW",
        "n": "North Rhine-Westphalia"
    }, {
        "c": "RP",
        "n": "Rhineland-Palatinate"
    }, {
        "c": "SL",
        "n": "Saarland"
    }, {
        "c": "SN",
        "n": "Saxony"
    }, {
        "c": "ST",
        "n": "Saxony-Anhalt"
    }, {
        "c": "SH",
        "n": "Schleswig-Holstein"
    }, {
        "c": "TH",
        "n": "Thuringia"
    }],
    "DK": [{
        "c": "84",
        "n": "Capital Region of Denmark"
    }, {
        "c": "82",
        "n": "Central Denmark Region"
    }, {
        "c": "81",
        "n": "North Denmark Region"
    }, {
        "c": "85",
        "n": "Zealand Region"
    }, {
        "c": "83",
        "n": "Southern Denmark Region"
    }],
    "DO": [{
        "c": "01",
        "n": "Distrito Nacional"
    }, {
        "c": "02",
        "n": "Azua"
    }, {
        "c": "03",
        "n": "Baoruco"
    }, {
        "c": "04",
        "n": "Barahona"
    }, {
        "c": "05",
        "n": "Dajabón"
    }, {
        "c": "06",
        "n": "Duarte"
    }, {
        "c": "08",
        "n": "El Seibo"
    }, {
        "c": "09",
        "n": "Espaillat"
    }, {
        "c": "30",
        "n": "Hato Mayor"
    }, {
        "c": "10",
        "n": "Independencia"
    }, {
        "c": "11",
        "n": "La Altagracia"
    }, {
        "c": "07",
        "n": "Elías Piña"
    }, {
        "c": "12",
        "n": "La Romana"
    }, {
        "c": "13",
        "n": "La Vega"
    }, {
        "c": "14",
        "n": "María Trinidad Sánchez"
    }, {
        "c": "28",
        "n": "Monseñor Nouel"
    }, {
        "c": "15",
        "n": "Monte Cristi"
    }, {
        "c": "29",
        "n": "Monte Plata"
    }, {
        "c": "16",
        "n": "Pedernales"
    }, {
        "c": "17",
        "n": "Peravia"
    }, {
        "c": "18",
        "n": "Puerto Plata"
    }, {
        "c": "19",
        "n": "Hermanas Mirabal"
    }, {
        "c": "20",
        "n": "Samaná"
    }, {
        "c": "21",
        "n": "San Cristóbal"
    }, {
        "c": "31",
        "n": "San José de Ocoa"
    }, {
        "c": "22",
        "n": "San Juan"
    }, {
        "c": "23",
        "n": "San Pedro de Macorís"
    }, {
        "c": "24",
        "n": "Sánchez Ramírez"
    }, {
        "c": "25",
        "n": "Santiago"
    }, {
        "c": "26",
        "n": "Santiago Rodríguez"
    }, {
        "c": "32",
        "n": "Santo Domingo"
    }, {
        "c": "27",
        "n": "Valverde"
    }],
    "DZ": [{
        "c": "01",
        "n": "Adrar"
    }, {
        "c": "02",
        "n": "Chlef"
    }, {
        "c": "03",
        "n": "Laghouat"
    }, {
        "c": "04",
        "n": "Oum el Bouaghi"
    }, {
        "c": "05",
        "n": "Batna"
    }, {
        "c": "06",
        "n": "Béjaïa"
    }, {
        "c": "07",
        "n": "Biskra"
    }, {
        "c": "08",
        "n": "Béchar"
    }, {
        "c": "09",
        "n": "Blida"
    }, {
        "c": "10",
        "n": "Bouira"
    }, {
        "c": "11",
        "n": "Tamanrasset"
    }, {
        "c": "12",
        "n": "Tébessa"
    }, {
        "c": "13",
        "n": "Tlemcen"
    }, {
        "c": "14",
        "n": "Tiaret"
    }, {
        "c": "15",
        "n": "Tizi Ouzou"
    }, {
        "c": "16",
        "n": "Alger"
    }, {
        "c": "17",
        "n": "Djelfa"
    }, {
        "c": "18",
        "n": "Jijel"
    }, {
        "c": "19",
        "n": "Sétif"
    }, {
        "c": "20",
        "n": "Saïda"
    }, {
        "c": "21",
        "n": "Skikda"
    }, {
        "c": "22",
        "n": "Sidi Bel Abbès"
    }, {
        "c": "23",
        "n": "Annaba"
    }, {
        "c": "24",
        "n": "Guelma"
    }, {
        "c": "25",
        "n": "Constantine"
    }, {
        "c": "26",
        "n": "Médéa"
    }, {
        "c": "27",
        "n": "Mostaganem"
    }, {
        "c": "28",
        "n": "M\u0027sila"
    }, {
        "c": "29",
        "n": "Mascara"
    }, {
        "c": "30",
        "n": "Ouargla"
    }, {
        "c": "31",
        "n": "Oran"
    }, {
        "c": "32",
        "n": "El Bayadh"
    }, {
        "c": "33",
        "n": "Illizi"
    }, {
        "c": "34",
        "n": "Bordj Bou Arréridj"
    }, {
        "c": "35",
        "n": "Boumerdès"
    }, {
        "c": "36",
        "n": "El Tarf"
    }, {
        "c": "37",
        "n": "Tindouf"
    }, {
        "c": "38",
        "n": "Tissemsilt"
    }, {
        "c": "39",
        "n": "El Oued"
    }, {
        "c": "40",
        "n": "Khenchela"
    }, {
        "c": "41",
        "n": "Souk Ahras"
    }, {
        "c": "42",
        "n": "Tipaza"
    }, {
        "c": "43",
        "n": "Mila"
    }, {
        "c": "44",
        "n": "Aïn Defla"
    }, {
        "c": "45",
        "n": "Naama"
    }, {
        "c": "46",
        "n": "Aïn Témouchent"
    }, {
        "c": "47",
        "n": "Ghardaïa"
    }, {
        "c": "48",
        "n": "Relizane"
    }, {
        "c": "49",
        "n": "El M\u0027Ghair"
    }, {
        "c": "50",
        "n": "El Menia"
    }, {
        "c": "51",
        "n": "Ouled Djellal"
    }, {
        "c": "52",
        "n": "Bordj Baji Mokhtar"
    }, {
        "c": "53",
        "n": "Béni Abbès"
    }, {
        "c": "54",
        "n": "Timimoun"
    }, {
        "c": "55",
        "n": "Touggourt"
    }, {
        "c": "56",
        "n": "Djanet"
    }, {
        "c": "57",
        "n": "In Salah"
    }, {
        "c": "58",
        "n": "In Guezzam"
    }],
    "EC": [{
        "c": "EC-A",
        "n": "Azuay",
        "lsc": "A"
    }, {
        "c": "EC-B",
        "n": "Bolívar",
        "lsc": "B"
    }, {
        "c": "EC-F",
        "n": "Cañar",
        "lsc": "F"
    }, {
        "c": "EC-C",
        "n": "Carchi",
        "lsc": "C"
    }, {
        "c": "EC-H",
        "n": "Chimborazo",
        "lsc": "H"
    }, {
        "c": "EC-X",
        "n": "Cotopaxi",
        "lsc": "X"
    }, {
        "c": "EC-O",
        "n": "El Oro",
        "lsc": "O"
    }, {
        "c": "EC-E",
        "n": "Esmeraldas",
        "lsc": "E"
    }, {
        "c": "EC-W",
        "n": "Galápagos",
        "lsc": "W"
    }, {
        "c": "EC-G",
        "n": "Guayas",
        "lsc": "G"
    }, {
        "c": "EC-I",
        "n": "Imbabura",
        "lsc": "I"
    }, {
        "c": "EC-L",
        "n": "Loja",
        "lsc": "L"
    }, {
        "c": "EC-R",
        "n": "Los Ríos",
        "lsc": "R"
    }, {
        "c": "EC-M",
        "n": "Manabí",
        "lsc": "M"
    }, {
        "c": "EC-S",
        "n": "Morona-Santiago",
        "lsc": "S"
    }, {
        "c": "EC-N",
        "n": "Napo",
        "lsc": "N"
    }, {
        "c": "EC-D",
        "n": "Orellana",
        "lsc": "D"
    }, {
        "c": "EC-Y",
        "n": "Pastaza",
        "lsc": "Y"
    }, {
        "c": "EC-P",
        "n": "Pichincha",
        "lsc": "P"
    }, {
        "c": "EC-SE",
        "n": "Santa Elena",
        "lsc": "SE"
    }, {
        "c": "EC-SD",
        "n": "Santo Domingo de los Tsáchilas",
        "lsc": "SD"
    }, {
        "c": "EC-U",
        "n": "Sucumbíos",
        "lsc": "U"
    }, {
        "c": "EC-T",
        "n": "Tungurahua",
        "lsc": "T"
    }, {
        "c": "EC-Z",
        "n": "Zamora-Chinchipe",
        "lsc": "Z"
    }],
    "EE": [{
        "c": "37",
        "n": "Harjumaa"
    }, {
        "c": "39",
        "n": "Hiiumaa"
    }, {
        "c": "44",
        "n": "Ida-Virumaa"
    }, {
        "c": "49",
        "n": "Jõgevamaa"
    }, {
        "c": "51",
        "n": "Järvamaa"
    }, {
        "c": "57",
        "n": "Läänemaa"
    }, {
        "c": "59",
        "n": "Lääne-Virumaa"
    }, {
        "c": "65",
        "n": "Põlvamaa"
    }, {
        "c": "67",
        "n": "Pärnumaa"
    }, {
        "c": "70",
        "n": "Raplamaa"
    }, {
        "c": "74",
        "n": "Saaremaa"
    }, {
        "c": "78",
        "n": "Tartumaa"
    }, {
        "c": "82",
        "n": "Valgamaa"
    }, {
        "c": "84",
        "n": "Viljandimaa"
    }, {
        "c": "86",
        "n": "Võrumaa"
    }],
    "EG": [{
        "c": "DK",
        "n": "Dakahlia"
    }, {
        "c": "BA",
        "n": "Red Sea"
    }, {
        "c": "BH",
        "n": "Beheira"
    }, {
        "c": "FYM",
        "n": "Faiyum"
    }, {
        "c": "GH",
        "n": "Gharbia"
    }, {
        "c": "ALX",
        "n": "Alexandria"
    }, {
        "c": "IS",
        "n": "Ismailia"
    }, {
        "c": "GZ",
        "n": "Giza"
    }, {
        "c": "MNF",
        "n": "Monufia"
    }, {
        "c": "MN",
        "n": "Minya"
    }, {
        "c": "C",
        "n": "Cairo"
    }, {
        "c": "KB",
        "n": "Qalyubia"
    }, {
        "c": "LX",
        "n": "Luxor"
    }, {
        "c": "WAD",
        "n": "New Valley"
    }, {
        "c": "SHR",
        "n": "Al Sharqia"
    }, {
        "c": "SUZ",
        "n": "Suez"
    }, {
        "c": "ASN",
        "n": "Aswan"
    }, {
        "c": "AST",
        "n": "Asyut"
    }, {
        "c": "BNS",
        "n": "Beni Suef"
    }, {
        "c": "PTS",
        "n": "Port Said"
    }, {
        "c": "DT",
        "n": "Damietta"
    }, {
        "c": "JS",
        "n": "South Sinai"
    }, {
        "c": "KFS",
        "n": "Kafr el-Sheikh"
    }, {
        "c": "MT",
        "n": "Matruh"
    }, {
        "c": "KN",
        "n": "Qena"
    }, {
        "c": "SIN",
        "n": "North Sinai"
    }, {
        "c": "SHG",
        "n": "Sohag"
    }],
    "ES": [{
        "c": "LC",
        "n": "A Coruña"
    }, {
        "c": "AL",
        "n": "Alava"
    }, {
        "c": "AB",
        "n": "Albacete"
    }, {
        "c": "AA",
        "n": "Alicante"
    }, {
        "c": "AM",
        "n": "Almeria"
    }, {
        "c": "AS",
        "n": "Asturias"
    }, {
        "c": "AV",
        "n": "Avila"
    }, {
        "c": "BA",
        "n": "Badajoz"
    }, {
        "c": "BC",
        "n": "Barcelona"
    }, {
        "c": "VI",
        "n": "Bizkaia"
    }, {
        "c": "BU",
        "n": "Burgos"
    }, {
        "c": "CC",
        "n": "Caceres"
    }, {
        "c": "CD",
        "n": "Cadiz"
    }, {
        "c": "CT",
        "n": "Cantabria"
    }, {
        "c": "CS",
        "n": "Castellon"
    }, {
        "c": "CE",
        "n": "Ceuta"
    }, {
        "c": "CR",
        "n": "Ciudad Real"
    }, {
        "c": "CO",
        "n": "Cordoba"
    }, {
        "c": "CU",
        "n": "Cuenca"
    }, {
        "c": "GI",
        "n": "Girona"
    }, {
        "c": "GP",
        "n": "Gipuzkoa"
    }, {
        "c": "GR",
        "n": "Granada"
    }, {
        "c": "GU",
        "n": "Guadalajara"
    }, {
        "c": "HU",
        "n": "Huelva"
    }, {
        "c": "HS",
        "n": "Huesca"
    }, {
        "c": "IB",
        "n": "Illes Balears"
    }, {
        "c": "JA",
        "n": "Jaen"
    }, {
        "c": "LR",
        "n": "La Rioja"
    }, {
        "c": "LP",
        "n": "Las Palmas"
    }, {
        "c": "LE",
        "n": "Leon"
    }, {
        "c": "LD",
        "n": "Lleida"
    }, {
        "c": "LU",
        "n": "Lugo"
    }, {
        "c": "MD",
        "n": "Madrid"
    }, {
        "c": "MA",
        "n": "Malaga"
    }, {
        "c": "ME",
        "n": "Melilla"
    }, {
        "c": "MU",
        "n": "Murcia"
    }, {
        "c": "NA",
        "n": "Navarra"
    }, {
        "c": "OR",
        "n": "Ourense"
    }, {
        "c": "PA",
        "n": "Palencia"
    }, {
        "c": "PO",
        "n": "Pontevedra"
    }, {
        "c": "SA",
        "n": "Salamanca"
    }, {
        "c": "SG",
        "n": "Segovia"
    }, {
        "c": "SE",
        "n": "Sevilla"
    }, {
        "c": "SO",
        "n": "Soria"
    }, {
        "c": "TA",
        "n": "Tarragona"
    }, {
        "c": "TF",
        "n": "Santa Cruz de Tenerife"
    }, {
        "c": "TE",
        "n": "Teruel"
    }, {
        "c": "TO",
        "n": "Toledo"
    }, {
        "c": "VC",
        "n": "Valencia"
    }, {
        "c": "VD",
        "n": "Valladolid"
    }, {
        "c": "ZM",
        "n": "Zamora"
    }, {
        "c": "ZA",
        "n": "Zaragoza"
    }],
    "FI": [{
        "c": "01",
        "n": "Åland"
    }, {
        "c": "02",
        "n": "South Karelia"
    }, {
        "c": "03",
        "n": "Southern Ostrobothnia"
    }, {
        "c": "04",
        "n": "Savonia"
    }, {
        "c": "05",
        "n": "Kainuu"
    }, {
        "c": "06",
        "n": "Tavastia Proper"
    }, {
        "c": "07",
        "n": "Central Ostrobothnia"
    }, {
        "c": "08",
        "n": "Central Finland"
    }, {
        "c": "09",
        "n": "Kymenlaakso"
    }, {
        "c": "10",
        "n": "Lapland"
    }, {
        "c": "11",
        "n": "Pirkanmaa"
    }, {
        "c": "12",
        "n": "Ostrobothnia"
    }, {
        "c": "13",
        "n": "North Karelia"
    }, {
        "c": "14",
        "n": "Northern Ostrobothnia"
    }, {
        "c": "15",
        "n": "Northern Savonia"
    }, {
        "c": "16",
        "n": "Päijänne Tavastia"
    }, {
        "c": "17",
        "n": "Satakunta"
    }, {
        "c": "18",
        "n": "Uusimaa"
    }, {
        "c": "19",
        "n": "Southwest Finland"
    }],
    "FR": [{
        "c": "01",
        "n": "Ain"
    }, {
        "c": "02",
        "n": "Aisne"
    }, {
        "c": "03",
        "n": "Allier"
    }, {
        "c": "04",
        "n": "Alpes-de-Haute-Provence"
    }, {
        "c": "06",
        "n": "Alpes-Maritimes"
    }, {
        "c": "07",
        "n": "Ardèche"
    }, {
        "c": "08",
        "n": "Ardennes"
    }, {
        "c": "09",
        "n": "Ariège"
    }, {
        "c": "10",
        "n": "Aube"
    }, {
        "c": "11",
        "n": "Aude"
    }, {
        "c": "12",
        "n": "Aveyron"
    }, {
        "c": "67",
        "n": "Bas-Rhin"
    }, {
        "c": "13",
        "n": "Bouches-du-Rhône"
    }, {
        "c": "14",
        "n": "Calvados"
    }, {
        "c": "15",
        "n": "Cantal"
    }, {
        "c": "16",
        "n": "Charente"
    }, {
        "c": "17",
        "n": "Charente-Maritime"
    }, {
        "c": "18",
        "n": "Cher"
    }, {
        "c": "19",
        "n": "Corrèze"
    }, {
        "c": "2A",
        "n": "Corse-du-Sud"
    }, {
        "c": "21",
        "n": "Côte-d\u0027Or"
    }, {
        "c": "22",
        "n": "Côtes-d\u0027Armor"
    }, {
        "c": "23",
        "n": "Creuse"
    }, {
        "c": "79",
        "n": "Deux-Sevres"
    }, {
        "c": "24",
        "n": "Dordogne"
    }, {
        "c": "25",
        "n": "Doubs"
    }, {
        "c": "26",
        "n": "Drôme"
    }, {
        "c": "91",
        "n": "Essonne"
    }, {
        "c": "27",
        "n": "Eure"
    }, {
        "c": "28",
        "n": "Eure-et-Loir"
    }, {
        "c": "29",
        "n": "Finistère"
    }, {
        "c": "30",
        "n": "Gard"
    }, {
        "c": "32",
        "n": "Gers"
    }, {
        "c": "33",
        "n": "Gironde"
    }, {
        "c": "971",
        "n": "Guadeloupe"
    }, {
        "c": "973",
        "n": "Guyane"
    }, {
        "c": "68",
        "n": "Haut-Rhin"
    }, {
        "c": "2B",
        "n": "Haute-Corse"
    }, {
        "c": "31",
        "n": "Haute-Garonne"
    }, {
        "c": "43",
        "n": "Haute-Loire"
    }, {
        "c": "52",
        "n": "Haute-Marne"
    }, {
        "c": "70",
        "n": "Haute-Saône"
    }, {
        "c": "74",
        "n": "Haute-Savoie"
    }, {
        "c": "87",
        "n": "Haute-Vienne"
    }, {
        "c": "05",
        "n": "Hautes-Alpes"
    }, {
        "c": "65",
        "n": "Hautes-Pyrénées"
    }, {
        "c": "92",
        "n": "Hauts-de-Seine"
    }, {
        "c": "34",
        "n": "Hérault"
    }, {
        "c": "35",
        "n": "Ille-et-Vilaine"
    }, {
        "c": "36",
        "n": "Indre"
    }, {
        "c": "37",
        "n": "Indre-et-Loire"
    }, {
        "c": "38",
        "n": "Isère"
    }, {
        "c": "39",
        "n": "Jura"
    }, {
        "c": "974",
        "n": "La Réunion"
    }, {
        "c": "40",
        "n": "Landes"
    }, {
        "c": "FR-J",
        "n": "Île-de-France",
        "lsc": "J"
    }, {
        "c": "41",
        "n": "Loir-et-Cher"
    }, {
        "c": "42",
        "n": "Loire"
    }, {
        "c": "44",
        "n": "Loire-Atlantique"
    }, {
        "c": "45",
        "n": "Loiret"
    }, {
        "c": "46",
        "n": "Lot"
    }, {
        "c": "47",
        "n": "Lot-et-Garonne"
    }, {
        "c": "48",
        "n": "Lozère"
    }, {
        "c": "49",
        "n": "Maine-et-Loire"
    }, {
        "c": "50",
        "n": "Manche"
    }, {
        "c": "51",
        "n": "Marne"
    }, {
        "c": "972",
        "n": "Martinique"
    }, {
        "c": "53",
        "n": "Mayenne"
    }, {
        "c": "976",
        "n": "Mayotte"
    }, {
        "c": "54",
        "n": "Meurthe-et-Moselle"
    }, {
        "c": "55",
        "n": "Meuse"
    }, {
        "c": "56",
        "n": "Morbihan"
    }, {
        "c": "57",
        "n": "Moselle"
    }, {
        "c": "58",
        "n": "Nièvre"
    }, {
        "c": "59",
        "n": "Nord"
    }, {
        "c": "60",
        "n": "Oise"
    }, {
        "c": "61",
        "n": "Orne"
    }, {
        "c": "75",
        "n": "Paris"
    }, {
        "c": "62",
        "n": "Pas-de-Calais"
    }, {
        "c": "63",
        "n": "Puy-de-Dôme"
    }, {
        "c": "64",
        "n": "Pyrénées-Atlantiques"
    }, {
        "c": "66",
        "n": "Pyrénées-Orientales"
    }, {
        "c": "69",
        "n": "Rhône"
    }, {
        "c": "71",
        "n": "Saône-et-Loire"
    }, {
        "c": "72",
        "n": "Sarthe"
    }, {
        "c": "73",
        "n": "Savoie"
    }, {
        "c": "77",
        "n": "Seine-et-Marne"
    }, {
        "c": "76",
        "n": "Seine-Maritime"
    }, {
        "c": "93",
        "n": "Seine-Saint-Denis"
    }, {
        "c": "80",
        "n": "Somme"
    }, {
        "c": "81",
        "n": "Tarn"
    }, {
        "c": "82",
        "n": "Tarn-et-Garonne"
    }, {
        "c": "90",
        "n": "Territoire de Belfort"
    }, {
        "c": "95",
        "n": "Val-d\u0027Oise"
    }, {
        "c": "94",
        "n": "Val-de-Marne"
    }, {
        "c": "83",
        "n": "Var"
    }, {
        "c": "84",
        "n": "Vaucluse"
    }, {
        "c": "85",
        "n": "Vendée"
    }, {
        "c": "86",
        "n": "Vienne"
    }, {
        "c": "88",
        "n": "Vosges"
    }, {
        "c": "89",
        "n": "Yonne"
    }, {
        "c": "78",
        "n": "Yvelines"
    }],
    "GB": [{
        "c": "ABE",
        "n": "Aberdeen"
    }, {
        "c": "ABD",
        "n": "Aberdeenshire"
    }, {
        "c": "ANS",
        "n": "Angus"
    }, {
        "c": "ANT",
        "n": "Antrim"
    }, {
        "c": "ARD",
        "n": "Ards"
    }, {
        "c": "AGB",
        "n": "Argyll and Bute"
    }, {
        "c": "ARM",
        "n": "Armagh"
    }, {
        "c": "BLA",
        "n": "Ballymena"
    }, {
        "c": "BLY",
        "n": "Ballymoney"
    }, {
        "c": "BNB",
        "n": "Banbridge"
    }, {
        "c": "BDG",
        "n": "Barking and Dagenham"
    }, {
        "c": "BNE",
        "n": "Barnet"
    }, {
        "c": "BNS",
        "n": "Barnsley"
    }, {
        "c": "BAS",
        "n": "Bath and North East Somerset"
    }, {
        "c": "BDF",
        "n": "Bedfordshire"
    }, {
        "c": "BFS",
        "n": "Belfast"
    }, {
        "c": "BRK",
        "n": "Berkshire"
    }, {
        "c": "BEX",
        "n": "Bexley"
    }, {
        "c": "BIR",
        "n": "Birmingham"
    }, {
        "c": "BBD",
        "n": "Blackburn with Darwen"
    }, {
        "c": "BPL",
        "n": "Blackpool"
    }, {
        "c": "BGW",
        "n": "Blaenau Gwent"
    }, {
        "c": "BOL",
        "n": "Bolton"
    }, {
        "c": "BMH",
        "n": "Bournemouth"
    }, {
        "c": "BRC",
        "n": "Bracknell Forest"
    }, {
        "c": "BRD",
        "n": "Bradford"
    }, {
        "c": "BEN",
        "n": "Brent"
    }, {
        "c": "BGE",
        "n": "Bridgend"
    }, {
        "c": "BNH",
        "n": "Brighton and Hove"
    }, {
        "c": "BST",
        "n": "Bristol"
    }, {
        "c": "BRY",
        "n": "Bromley"
    }, {
        "c": "BKM",
        "n": "Buckinghamshire"
    }, {
        "c": "BUR",
        "n": "Bury"
    }, {
        "c": "CAY",
        "n": "Caerphilly"
    }, {
        "c": "CLD",
        "n": "Calderdale"
    }, {
        "c": "CAM",
        "n": "Cambridgeshire"
    }, {
        "c": "CMD",
        "n": "Camden"
    }, {
        "c": "CRF",
        "n": "Cardiff"
    }, {
        "c": "CMN",
        "n": "Carmarthenshire"
    }, {
        "c": "CKF",
        "n": "Carrickfergus"
    }, {
        "c": "CSR",
        "n": "Castlereagh"
    }, {
        "c": "CGN",
        "n": "Ceredigion"
    }, {
        "c": "CHS",
        "n": "Cheshire"
    }, {
        "c": "CLK",
        "n": "Clackmannanshire"
    }, {
        "c": "CLR",
        "n": "Coleraine"
    }, {
        "c": "CWY",
        "n": "Conwy"
    }, {
        "c": "CKT",
        "n": "Cookstown"
    }, {
        "c": "CON",
        "n": "Cornwall"
    }, {
        "c": "COV",
        "n": "Coventry"
    }, {
        "c": "CGV",
        "n": "Craigavon"
    }, {
        "c": "CRY",
        "n": "Croydon"
    }, {
        "c": "CMA",
        "n": "Cumbria"
    }, {
        "c": "DAL",
        "n": "Darlington"
    }, {
        "c": "DEN",
        "n": "Denbighshire"
    }, {
        "c": "DER",
        "n": "Derby"
    }, {
        "c": "DBY",
        "n": "Derbyshire"
    }, {
        "c": "DRY",
        "n": "Derry"
    }, {
        "c": "DEV",
        "n": "Devon"
    }, {
        "c": "DNC",
        "n": "Doncaster"
    }, {
        "c": "DOR",
        "n": "Dorset"
    }, {
        "c": "DOW",
        "n": "Down"
    }, {
        "c": "DUD",
        "n": "Dudley"
    }, {
        "c": "DGY",
        "n": "Dumfries and Galloway"
    }, {
        "c": "DND",
        "n": "Dundee"
    }, {
        "c": "DGN",
        "n": "Dungannon and South Tyrone"
    }, {
        "c": "DUR",
        "n": "Durham"
    }, {
        "c": "EAL",
        "n": "Ealing"
    }, {
        "c": "EAY",
        "n": "East Ayrshire"
    }, {
        "c": "EDU",
        "n": "East Dunbartonshire"
    }, {
        "c": "ELN",
        "n": "East Lothian"
    }, {
        "c": "ERW",
        "n": "East Renfrewshire"
    }, {
        "c": "ERY",
        "n": "East Riding of Yorkshire"
    }, {
        "c": "ESX",
        "n": "East Sussex"
    }, {
        "c": "EDH",
        "n": "Edinburgh"
    }, {
        "c": "ELS",
        "n": "Eilean Siar"
    }, {
        "c": "ENF",
        "n": "Enfield"
    }, {
        "c": "ESS",
        "n": "Essex"
    }, {
        "c": "FAL",
        "n": "Falkirk"
    }, {
        "c": "FER",
        "n": "Fermanagh"
    }, {
        "c": "FIF",
        "n": "Fife"
    }, {
        "c": "FLN",
        "n": "Flintshire"
    }, {
        "c": "GAT",
        "n": "Gateshead"
    }, {
        "c": "GLG",
        "n": "Glasgow"
    }, {
        "c": "GLS",
        "n": "Gloucestershire"
    }, {
        "c": "GRE",
        "n": "Greenwich"
    }, {
        "c": "GSY",
        "n": "Guernsey"
    }, {
        "c": "GWN",
        "n": "Gwynedd"
    }, {
        "c": "HCK",
        "n": "Hackney"
    }, {
        "c": "HAL",
        "n": "Halton"
    }, {
        "c": "HMF",
        "n": "Hammersmith and Fulham"
    }, {
        "c": "HAM",
        "n": "Hampshire"
    }, {
        "c": "HRY",
        "n": "Haringey"
    }, {
        "c": "HRW",
        "n": "Harrow"
    }, {
        "c": "HPL",
        "n": "Hartlepool"
    }, {
        "c": "HAV",
        "n": "Havering"
    }, {
        "c": "HEF",
        "n": "Herefordshire"
    }, {
        "c": "HRT",
        "n": "Hertfordshire"
    }, {
        "c": "HLD",
        "n": "Highland"
    }, {
        "c": "HIL",
        "n": "Hillingdon"
    }, {
        "c": "HNS",
        "n": "Hounslow"
    }, {
        "c": "IVC",
        "n": "Inverclyde"
    }, {
        "c": "AGY",
        "n": "Isle of Anglesey"
    }, {
        "c": "IOW",
        "n": "Isle of Wight"
    }, {
        "c": "IOS",
        "n": "Isles of Scilly"
    }, {
        "c": "ISL",
        "n": "Islington"
    }, {
        "c": "JSY",
        "n": "Jersey"
    }, {
        "c": "KEC",
        "n": "Kensington and Chelsea"
    }, {
        "c": "KEN",
        "n": "Kent"
    }, {
        "c": "KHL",
        "n": "Kingston upon Hull"
    }, {
        "c": "KTT",
        "n": "Kingston upon Thames"
    }, {
        "c": "KIR",
        "n": "Kirklees"
    }, {
        "c": "KWL",
        "n": "Knowsley"
    }, {
        "c": "LBH",
        "n": "Lambeth"
    }, {
        "c": "LAN",
        "n": "Lancashire"
    }, {
        "c": "LRN",
        "n": "Larne"
    }, {
        "c": "LDS",
        "n": "Leeds"
    }, {
        "c": "LCE",
        "n": "Leicester"
    }, {
        "c": "LEC",
        "n": "Leicestershire"
    }, {
        "c": "LEW",
        "n": "Lewisham"
    }, {
        "c": "LMV",
        "n": "Limavady"
    }, {
        "c": "LIN",
        "n": "Lincolnshire"
    }, {
        "c": "LSB",
        "n": "Lisburn"
    }, {
        "c": "LIV",
        "n": "Liverpool"
    }, {
        "c": "LND",
        "n": "London"
    }, {
        "c": "LUT",
        "n": "Luton"
    }, {
        "c": "MFT",
        "n": "Magherafelt"
    }, {
        "c": "MAN",
        "n": "Manchester"
    }, {
        "c": "MDW",
        "n": "Medway"
    }, {
        "c": "MTY",
        "n": "Merthyr Tydfil"
    }, {
        "c": "MRT",
        "n": "Merton"
    }, {
        "c": "MDB",
        "n": "Middlesbrough"
    }, {
        "c": "MDX",
        "n": "Middlesex"
    }, {
        "c": "MLN",
        "n": "Midlothian"
    }, {
        "c": "MIK",
        "n": "Milton Keynes"
    }, {
        "c": "MON",
        "n": "Monmouthshire"
    }, {
        "c": "MRY",
        "n": "Moray"
    }, {
        "c": "MYL",
        "n": "Moyle"
    }, {
        "c": "NTL",
        "n": "Neath Port Talbot"
    }, {
        "c": "NET",
        "n": "Newcastle upon Tyne"
    }, {
        "c": "NWM",
        "n": "Newham"
    }, {
        "c": "NWP",
        "n": "Newport"
    }, {
        "c": "NYM",
        "n": "Newry and Mourne"
    }, {
        "c": "NTA",
        "n": "Newtownabbey"
    }, {
        "c": "NFK",
        "n": "Norfolk"
    }, {
        "c": "NAY",
        "n": "North Ayrshire"
    }, {
        "c": "NDN",
        "n": "North Down"
    }, {
        "c": "NEL",
        "n": "North East Lincolnshire"
    }, {
        "c": "NLK",
        "n": "North Lanarkshire"
    }, {
        "c": "NLN",
        "n": "North Lincolnshire"
    }, {
        "c": "NSM",
        "n": "North Somerset"
    }, {
        "c": "NTY",
        "n": "North Tyneside"
    }, {
        "c": "NYK",
        "n": "North Yorkshire"
    }, {
        "c": "NTH",
        "n": "Northamptonshire"
    }, {
        "c": "NBL",
        "n": "Northumberland"
    }, {
        "c": "NGM",
        "n": "Nottingham"
    }, {
        "c": "NTT",
        "n": "Nottinghamshire"
    }, {
        "c": "OLD",
        "n": "Oldham"
    }, {
        "c": "OMH",
        "n": "Omagh"
    }, {
        "c": "ORK",
        "n": "Orkney Islands"
    }, {
        "c": "OXF",
        "n": "Oxfordshire"
    }, {
        "c": "PEM",
        "n": "Pembrokeshire"
    }, {
        "c": "PKN",
        "n": "Perth and Kinross"
    }, {
        "c": "PTE",
        "n": "Peterborough"
    }, {
        "c": "PLY",
        "n": "Plymouth"
    }, {
        "c": "POL",
        "n": "Poole"
    }, {
        "c": "POR",
        "n": "Portsmouth"
    }, {
        "c": "POW",
        "n": "Powys"
    }, {
        "c": "RDG",
        "n": "Reading"
    }, {
        "c": "RDB",
        "n": "Redbridge"
    }, {
        "c": "RCC",
        "n": "Redcar and Cleveland"
    }, {
        "c": "RFW",
        "n": "Renfrewshire"
    }, {
        "c": "RCT",
        "n": "Rhondda Cynon Taf"
    }, {
        "c": "RIC",
        "n": "Richmond upon Thames"
    }, {
        "c": "RCH",
        "n": "Rochdale"
    }, {
        "c": "ROT",
        "n": "Rotherham"
    }, {
        "c": "RUT",
        "n": "Rutland"
    }, {
        "c": "SLF",
        "n": "Salford"
    }, {
        "c": "SAW",
        "n": "Sandwell"
    }, {
        "c": "SCB",
        "n": "Scottish Borders"
    }, {
        "c": "SFT",
        "n": "Sefton"
    }, {
        "c": "SHF",
        "n": "Sheffield"
    }, {
        "c": "ZET",
        "n": "Shetland Islands"
    }, {
        "c": "SHR",
        "n": "Shropshire"
    }, {
        "c": "SLG",
        "n": "Slough"
    }, {
        "c": "SOL",
        "n": "Solihull"
    }, {
        "c": "SOM",
        "n": "Somerset"
    }, {
        "c": "SAY",
        "n": "South Ayrshire"
    }, {
        "c": "SGC",
        "n": "South Gloucestershire"
    }, {
        "c": "SLK",
        "n": "South Lanarkshire"
    }, {
        "c": "STY",
        "n": "South Tyneside"
    }, {
        "c": "STH",
        "n": "Southampton"
    }, {
        "c": "SOS",
        "n": "Southend-on-Sea"
    }, {
        "c": "SWK",
        "n": "Southwark"
    }, {
        "c": "SHN",
        "n": "St Helens"
    }, {
        "c": "STS",
        "n": "Staffordshire"
    }, {
        "c": "STG",
        "n": "Stirling"
    }, {
        "c": "SKP",
        "n": "Stockport"
    }, {
        "c": "STT",
        "n": "Stockton-on-Tees"
    }, {
        "c": "STE",
        "n": "Stoke-on-Trent"
    }, {
        "c": "STB",
        "n": "Strabane"
    }, {
        "c": "SFK",
        "n": "Suffolk"
    }, {
        "c": "SND",
        "n": "Sunderland"
    }, {
        "c": "SRY",
        "n": "Surrey"
    }, {
        "c": "STN",
        "n": "Sutton"
    }, {
        "c": "SWA",
        "n": "Swansea"
    }, {
        "c": "SWD",
        "n": "Swindon"
    }, {
        "c": "SYK",
        "n": "South Yorkshire"
    }, {
        "c": "TAM",
        "n": "Tameside"
    }, {
        "c": "TFW",
        "n": "Telford and Wrekin"
    }, {
        "c": "THR",
        "n": "Thurrock"
    }, {
        "c": "TOB",
        "n": "Torbay"
    }, {
        "c": "TOF",
        "n": "Torfaen"
    }, {
        "c": "TWH",
        "n": "Tower Hamlets"
    }, {
        "c": "TRF",
        "n": "Trafford"
    }, {
        "c": "VGL",
        "n": "Vale of Glamorgan"
    }, {
        "c": "WKF",
        "n": "Wakefield"
    }, {
        "c": "WLL",
        "n": "Walsall"
    }, {
        "c": "WFT",
        "n": "Waltham Forest"
    }, {
        "c": "WND",
        "n": "Wandsworth"
    }, {
        "c": "WRT",
        "n": "Warrington"
    }, {
        "c": "WAR",
        "n": "Warwickshire"
    }, {
        "c": "WBK",
        "n": "West Berkshire"
    }, {
        "c": "WDU",
        "n": "West Dunbartonshire"
    }, {
        "c": "WLN",
        "n": "West Lothian"
    }, {
        "c": "WSX",
        "n": "West Sussex"
    }, {
        "c": "WSM",
        "n": "Westminster"
    }, {
        "c": "WGN",
        "n": "Wigan"
    }, {
        "c": "WIL",
        "n": "Wiltshire"
    }, {
        "c": "WNM",
        "n": "Windsor and Maidenhead"
    }, {
        "c": "WRL",
        "n": "Wirral"
    }, {
        "c": "WOK",
        "n": "Wokingham"
    }, {
        "c": "WLV",
        "n": "Wolverhampton"
    }, {
        "c": "WMD",
        "n": "West Midlands"
    }, {
        "c": "WOR",
        "n": "Worcestershire"
    }, {
        "c": "WRX",
        "n": "Wrexham"
    }, {
        "c": "WYK",
        "n": "West Yorkshire"
    }, {
        "c": "YKS",
        "n": "Yorkshire"
    }, {
        "c": "YOR",
        "n": "York"
    }],
    "GE": [{
        "c": "AB",
        "n": "Abkhazia"
    }, {
        "c": "AJ",
        "n": "Ajaria"
    }, {
        "c": "TB",
        "n": "Tbilisi"
    }, {
        "c": "GU",
        "n": "Guria"
    }, {
        "c": "IM",
        "n": "Imereti"
    }, {
        "c": "KA",
        "n": "K\u0027akheti"
    }, {
        "c": "KK",
        "n": "Kvemo Kartli"
    }, {
        "c": "MM",
        "n": "Mtskheta-Mtianeti"
    }, {
        "c": "RL",
        "n": "Rach\u0027a-Lechkhumi-Kvemo Svaneti"
    }, {
        "c": "SZ",
        "n": "Samegrelo-Zemo Svaneti"
    }, {
        "c": "SJ",
        "n": "Samtskhe-Javakheti"
    }, {
        "c": "SK",
        "n": "Shida Kartli"
    }],
    "GH": [{
        "c": "GH-AF",
        "n": "Ahafo",
        "lsc": "AF"
    }, {
        "c": "GH-AH",
        "n": "Ashanti",
        "lsc": "AH"
    }, {
        "c": "GH-BO",
        "n": "Bono",
        "lsc": "BO"
    }, {
        "c": "GH-BE",
        "n": "Bono East",
        "lsc": "BE"
    }, {
        "c": "GH-BA",
        "n": "Brong-Ahafo",
        "lsc": "BA"
    }, {
        "c": "GH-CP",
        "n": "Central",
        "lsc": "CP"
    }, {
        "c": "GH-EP",
        "n": "Eastern",
        "lsc": "EP"
    }, {
        "c": "GH-AA",
        "n": "Greater Accra",
        "lsc": "AA"
    }, {
        "c": "GH-NE",
        "n": "North East",
        "lsc": "NE"
    }, {
        "c": "GH-NP",
        "n": "Northern",
        "lsc": "NP"
    }, {
        "c": "GH-OT",
        "n": "Oti",
        "lsc": "OT"
    }, {
        "c": "GH-SV",
        "n": "Savannah",
        "lsc": "SV"
    }, {
        "c": "GH-UE",
        "n": "Upper East",
        "lsc": "UE"
    }, {
        "c": "GH-UW",
        "n": "Upper West",
        "lsc": "UW"
    }, {
        "c": "GH-TV",
        "n": "Volta",
        "lsc": "TV"
    }, {
        "c": "GH-WP",
        "n": "Western",
        "lsc": "WP"
    }, {
        "c": "GH-WN",
        "n": "Western North",
        "lsc": "WN"
    }],
    "GR": [{
        "c": "GR-A",
        "n": "Anatolikí Makedonía kai Thráki",
        "lsc": "A"
    }, {
        "c": "GR-B",
        "n": "Kentrikí Makedonía",
        "lsc": "B"
    }, {
        "c": "GR-C",
        "n": "Dytikí Makedonía",
        "lsc": "C"
    }, {
        "c": "GR-D",
        "n": "Ípeiros",
        "lsc": "D"
    }, {
        "c": "GR-E",
        "n": "Thessalía",
        "lsc": "E"
    }, {
        "c": "GR-F",
        "n": "Ionía Nísia",
        "lsc": "F"
    }, {
        "c": "GR-G",
        "n": "Dytikí Elláda",
        "lsc": "G"
    }, {
        "c": "GR-H",
        "n": "Stereá Elláda",
        "lsc": "H"
    }, {
        "c": "GR-I",
        "n": "Attikí",
        "lsc": "I"
    }, {
        "c": "GR-J",
        "n": "Peloponnísos",
        "lsc": "J"
    }, {
        "c": "GR-K",
        "n": "Voreío Aigaío",
        "lsc": "K"
    }, {
        "c": "GR-L",
        "n": "Notío Aigaío",
        "lsc": "L"
    }, {
        "c": "GR-M",
        "n": "Kríti",
        "lsc": "M"
    }],
    "GT": [{
        "c": "AV",
        "n": "Alta Verapaz"
    }, {
        "c": "BV",
        "n": "Baja Verapaz"
    }, {
        "c": "CM",
        "n": "Chimaltenango"
    }, {
        "c": "CQ",
        "n": "Chiquimula"
    }, {
        "c": "PR",
        "n": "El Progreso"
    }, {
        "c": "ES",
        "n": "Escuintla"
    }, {
        "c": "GU",
        "n": "Guatemala"
    }, {
        "c": "HU",
        "n": "Huehuetenango"
    }, {
        "c": "IZ",
        "n": "Izabal"
    }, {
        "c": "JA",
        "n": "Jalapa"
    }, {
        "c": "JU",
        "n": "Jutiapa"
    }, {
        "c": "PE",
        "n": "Petén"
    }, {
        "c": "QZ",
        "n": "Quetzaltenango"
    }, {
        "c": "QC",
        "n": "Quiché"
    }, {
        "c": "RE",
        "n": "Retalhuleu"
    }, {
        "c": "SA",
        "n": "Sacatepéquez"
    }, {
        "c": "SM",
        "n": "San Marcos"
    }, {
        "c": "SR",
        "n": "Santa Rosa"
    }, {
        "c": "SO",
        "n": "Sololá"
    }, {
        "c": "SU",
        "n": "Suchitepéquez"
    }, {
        "c": "TO",
        "n": "Totonicapán"
    }, {
        "c": "ZA",
        "n": "Zacapa"
    }],
    "HN": [{
        "c": "HO01",
        "n": "Atlántida"
    }, {
        "c": "HO02",
        "n": "Choluteca"
    }, {
        "c": "HO03",
        "n": "Colón"
    }, {
        "c": "HO04",
        "n": "Comayagua"
    }, {
        "c": "HO05",
        "n": "Copán"
    }, {
        "c": "HO06",
        "n": "Cortés"
    }, {
        "c": "HO07",
        "n": "El Paraíso"
    }, {
        "c": "HO08",
        "n": "Francisco Morazán"
    }, {
        "c": "HO09",
        "n": "Gracias a Dios"
    }, {
        "c": "HO10",
        "n": "Intibucá"
    }, {
        "c": "HO11",
        "n": "Islas de la Bahía"
    }, {
        "c": "HO12",
        "n": "La Paz"
    }, {
        "c": "HO13",
        "n": "Lempira"
    }, {
        "c": "HO14",
        "n": "Ocotepeque"
    }, {
        "c": "HO15",
        "n": "Olancho"
    }, {
        "c": "HO16",
        "n": "Santa Bárbara"
    }, {
        "c": "HO17",
        "n": "Valle"
    }, {
        "c": "HO18",
        "n": "Yoro"
    }],
    "HU": [{
        "c": "BA",
        "n": "Baranya"
    }, {
        "c": "BE",
        "n": "Békés"
    }, {
        "c": "BK",
        "n": "Bács-Kiskun"
    }, {
        "c": "BU",
        "n": "Budapest"
    }, {
        "c": "BZ",
        "n": "Borsod-Abaúj-Zemplén"
    }, {
        "c": "CS",
        "n": "Csongrád"
    }, {
        "c": "FE",
        "n": "Fejér"
    }, {
        "c": "GS",
        "n": "Győr-Moson-Sopron"
    }, {
        "c": "HB",
        "n": "Hajdú-Bihar"
    }, {
        "c": "HE",
        "n": "Heves"
    }, {
        "c": "JN",
        "n": "Jász-Nagykun-Szolnok"
    }, {
        "c": "KE",
        "n": "Komárom-Esztergom"
    }, {
        "c": "NO",
        "n": "Nógrád"
    }, {
        "c": "PE",
        "n": "Pest"
    }, {
        "c": "SO",
        "n": "Somogy"
    }, {
        "c": "SZ",
        "n": "Szabolcs-Szatmár-Bereg"
    }, {
        "c": "TO",
        "n": "Tolna"
    }, {
        "c": "VA",
        "n": "Vas"
    }, {
        "c": "VE",
        "n": "Veszprém"
    }, {
        "c": "ZA",
        "n": "Zala"
    }],
    "ID": [{
        "c": "AC",
        "n": "Aceh"
    }, {
        "c": "BA",
        "n": "Bali"
    }, {
        "c": "BB",
        "n": "Bangka-Belitung"
    }, {
        "c": "BT",
        "n": "Banten"
    }, {
        "c": "BE",
        "n": "Bengkulu"
    }, {
        "c": "GO",
        "n": "Gorontalo"
    }, {
        "c": "JK",
        "n": "Jakarta Raya"
    }, {
        "c": "JA",
        "n": "Jambi"
    }, {
        "c": "JB",
        "n": "Jawa Barat"
    }, {
        "c": "JT",
        "n": "Jawa Tengah"
    }, {
        "c": "JI",
        "n": "Jawa Timur"
    }, {
        "c": "KB",
        "n": "Kalimantan Barat"
    }, {
        "c": "KS",
        "n": "Kalimantan Selatan"
    }, {
        "c": "KT",
        "n": "Kalimantan Tengah"
    }, {
        "c": "KI",
        "n": "Kalimantan Timur"
    }, {
        "c": "KU",
        "n": "Kalimantan Utara"
    }, {
        "c": "KR",
        "n": "Kepulauan Riau"
    }, {
        "c": "LA",
        "n": "Lampung"
    }, {
        "c": "MA",
        "n": "Maluku"
    }, {
        "c": "MU",
        "n": "Maluku Utara"
    }, {
        "c": "NB",
        "n": "Nusa Tenggara Barat"
    }, {
        "c": "NT",
        "n": "Nusa Tenggara Timur"
    }, {
        "c": "PA",
        "n": "Papua"
    }, {
        "c": "PB",
        "n": "Papua Barat"
    }, {
        "c": "RI",
        "n": "Riau"
    }, {
        "c": "SR",
        "n": "Sulawesi Barat"
    }, {
        "c": "SN",
        "n": "Sulawesi Selatan"
    }, {
        "c": "ST",
        "n": "Sulawesi Tengah"
    }, {
        "c": "SG",
        "n": "Sulawesi Tenggara"
    }, {
        "c": "SA",
        "n": "Sulawesi Utara"
    }, {
        "c": "SB",
        "n": "Sumatera Barat"
    }, {
        "c": "SS",
        "n": "Sumatera Selatan"
    }, {
        "c": "SU",
        "n": "Sumatera Utara"
    }, {
        "c": "YO",
        "n": "Yogyakarta"
    }],
    "IE": [{
        "c": "CW",
        "n": "Carlow"
    }, {
        "c": "CN",
        "n": "Cavan"
    }, {
        "c": "CE",
        "n": "Clare"
    }, {
        "c": "CO",
        "n": "Cork"
    }, {
        "c": "DL",
        "n": "Donegal"
    }, {
        "c": "D",
        "n": "Dublin"
    }, {
        "c": "G",
        "n": "Galway"
    }, {
        "c": "KY",
        "n": "Kerry"
    }, {
        "c": "KE",
        "n": "Kildare"
    }, {
        "c": "KK",
        "n": "Kilkenny"
    }, {
        "c": "LS",
        "n": "Laois"
    }, {
        "c": "LM",
        "n": "Leitrim"
    }, {
        "c": "LK",
        "n": "Limerick"
    }, {
        "c": "LD",
        "n": "Longford"
    }, {
        "c": "LH",
        "n": "Louth"
    }, {
        "c": "MO",
        "n": "Mayo"
    }, {
        "c": "MH",
        "n": "Meath"
    }, {
        "c": "MN",
        "n": "Monaghan"
    }, {
        "c": "OY",
        "n": "Offaly"
    }, {
        "c": "RN",
        "n": "Roscommon"
    }, {
        "c": "SO",
        "n": "Sligo"
    }, {
        "c": "TA",
        "n": "Tipperary"
    }, {
        "c": "WD",
        "n": "Waterford"
    }, {
        "c": "WH",
        "n": "Westmeath"
    }, {
        "c": "WX",
        "n": "Wexford"
    }, {
        "c": "WW",
        "n": "Wicklow"
    }],
    "IN": [{
        "c": "AP",
        "n": "Andhra Pradesh"
    }, {
        "c": "AR",
        "n": "Arunachal Pradesh"
    }, {
        "c": "AS",
        "n": "Assam"
    }, {
        "c": "BR",
        "n": "Bihar"
    }, {
        "c": "CT",
        "n": "Chhattisgarh"
    }, {
        "c": "GA",
        "n": "Goa"
    }, {
        "c": "GJ",
        "n": "Gujarat"
    }, {
        "c": "HR",
        "n": "Haryana"
    }, {
        "c": "HP",
        "n": "Himachal Pradesh"
    }, {
        "c": "JK",
        "n": "Jammu and Kashmir"
    }, {
        "c": "JH",
        "n": "Jharkhand"
    }, {
        "c": "KA",
        "n": "Karnataka"
    }, {
        "c": "KL",
        "n": "Kerala"
    }, {
        "c": "LA",
        "n": "Ladakh"
    }, {
        "c": "MP",
        "n": "Madhya Pradesh"
    }, {
        "c": "MH",
        "n": "Maharashtra"
    }, {
        "c": "MN",
        "n": "Manipur"
    }, {
        "c": "ML",
        "n": "Meghalaya"
    }, {
        "c": "MZ",
        "n": "Mizoram"
    }, {
        "c": "NL",
        "n": "Nagaland"
    }, {
        "c": "OR",
        "n": "Odisha"
    }, {
        "c": "PB",
        "n": "Punjab"
    }, {
        "c": "RJ",
        "n": "Rajasthan"
    }, {
        "c": "SK",
        "n": "Sikkim"
    }, {
        "c": "TN",
        "n": "Tamil Nadu"
    }, {
        "c": "TG",
        "n": "Telangana"
    }, {
        "c": "TR",
        "n": "Tripura"
    }, {
        "c": "UT",
        "n": "Uttarakhand"
    }, {
        "c": "UP",
        "n": "Uttar Pradesh"
    }, {
        "c": "WB",
        "n": "West Bengal"
    }, {
        "c": "AN",
        "n": "Andaman and Nicobar Islands"
    }, {
        "c": "CH",
        "n": "Chandigarh"
    }, {
        "c": "DN",
        "n": "Dadra and Nagar Haveli"
    }, {
        "c": "DD",
        "n": "Daman and Diu"
    }, {
        "c": "DL",
        "n": "Delhi"
    }, {
        "c": "LD",
        "n": "Lakshadweep"
    }, {
        "c": "PY",
        "n": "Puducherry"
    }, {
        "c": "APO",
        "n": "Army Post Office"
    }],
    "IT": [{
        "c": "AG",
        "n": "Agrigento"
    }, {
        "c": "AL",
        "n": "Alessandria"
    }, {
        "c": "AN",
        "n": "Ancona"
    }, {
        "c": "AO",
        "n": "Aosta"
    }, {
        "c": "AR",
        "n": "Arezzo"
    }, {
        "c": "AP",
        "n": "Ascoli Piceno"
    }, {
        "c": "AT",
        "n": "Asti"
    }, {
        "c": "AV",
        "n": "Avellino"
    }, {
        "c": "BA",
        "n": "Bari"
    }, {
        "c": "BT",
        "n": "Barletta-Andria-Trani"
    }, {
        "c": "BL",
        "n": "Belluno"
    }, {
        "c": "BN",
        "n": "Benevento"
    }, {
        "c": "BG",
        "n": "Bergamo"
    }, {
        "c": "BI",
        "n": "Biella"
    }, {
        "c": "BO",
        "n": "Bologna"
    }, {
        "c": "BZ",
        "n": "Bolzano"
    }, {
        "c": "BS",
        "n": "Brescia"
    }, {
        "c": "BR",
        "n": "Brindisi"
    }, {
        "c": "CA",
        "n": "Cagliari"
    }, {
        "c": "CL",
        "n": "Caltanissetta"
    }, {
        "c": "CB",
        "n": "Campobasso"
    }, {
        "c": "CI",
        "n": "Carbonia-Iglesias"
    }, {
        "c": "CE",
        "n": "Caserta"
    }, {
        "c": "CT",
        "n": "Catania"
    }, {
        "c": "CZ",
        "n": "Catanzaro"
    }, {
        "c": "CH",
        "n": "Chieti"
    }, {
        "c": "CO",
        "n": "Como"
    }, {
        "c": "CS",
        "n": "Cosenza"
    }, {
        "c": "CR",
        "n": "Cremona"
    }, {
        "c": "KR",
        "n": "Crotone"
    }, {
        "c": "CN",
        "n": "Cuneo"
    }, {
        "c": "EN",
        "n": "Enna"
    }, {
        "c": "FM",
        "n": "Fermo"
    }, {
        "c": "FE",
        "n": "Ferrara"
    }, {
        "c": "FI",
        "n": "Firenze"
    }, {
        "c": "FG",
        "n": "Foggia"
    }, {
        "c": "FC",
        "n": "Forlì-Cesena"
    }, {
        "c": "FR",
        "n": "Frosinone"
    }, {
        "c": "GE",
        "n": "Genova"
    }, {
        "c": "GO",
        "n": "Gorizia"
    }, {
        "c": "GR",
        "n": "Grosseto"
    }, {
        "c": "IM",
        "n": "Imperia"
    }, {
        "c": "IS",
        "n": "Isernia"
    }, {
        "c": "SP",
        "n": "La Spezia"
    }, {
        "c": "AQ",
        "n": "L\u0027Aquila"
    }, {
        "c": "LT",
        "n": "Latina"
    }, {
        "c": "LE",
        "n": "Lecce"
    }, {
        "c": "LC",
        "n": "Lecco"
    }, {
        "c": "LI",
        "n": "Livorno"
    }, {
        "c": "LO",
        "n": "Lodi"
    }, {
        "c": "LU",
        "n": "Lucca"
    }, {
        "c": "MC",
        "n": "Macerata"
    }, {
        "c": "MN",
        "n": "Mantova"
    }, {
        "c": "MS",
        "n": "Massa e Carrara"
    }, {
        "c": "MT",
        "n": "Matera"
    }, {
        "c": "VS",
        "n": "Medio Campidano"
    }, {
        "c": "ME",
        "n": "Messina"
    }, {
        "c": "MI",
        "n": "Milano"
    }, {
        "c": "MO",
        "n": "Modena"
    }, {
        "c": "MB",
        "n": "Monza e Brianza"
    }, {
        "c": "NA",
        "n": "Napoli"
    }, {
        "c": "NO",
        "n": "Novara"
    }, {
        "c": "NU",
        "n": "Nuoro"
    }, {
        "c": "OG",
        "n": "Ogliastra"
    }, {
        "c": "OT",
        "n": "Olbia-Tempio"
    }, {
        "c": "OR",
        "n": "Oristano"
    }, {
        "c": "PD",
        "n": "Padova"
    }, {
        "c": "PA",
        "n": "Palermo"
    }, {
        "c": "PR",
        "n": "Parma"
    }, {
        "c": "PV",
        "n": "Pavia"
    }, {
        "c": "PG",
        "n": "Perugia"
    }, {
        "c": "PU",
        "n": "Pesaro e Urbino"
    }, {
        "c": "PE",
        "n": "Pescara"
    }, {
        "c": "PC",
        "n": "Piacenza"
    }, {
        "c": "PI",
        "n": "Pisa"
    }, {
        "c": "PT",
        "n": "Pistoia"
    }, {
        "c": "PN",
        "n": "Pordenone"
    }, {
        "c": "PZ",
        "n": "Potenza"
    }, {
        "c": "PO",
        "n": "Prato"
    }, {
        "c": "RG",
        "n": "Ragusa"
    }, {
        "c": "RA",
        "n": "Ravenna"
    }, {
        "c": "RC",
        "n": "Reggio Calabria"
    }, {
        "c": "RE",
        "n": "Reggio Emilia"
    }, {
        "c": "RI",
        "n": "Rieti"
    }, {
        "c": "RN",
        "n": "Rimini"
    }, {
        "c": "RM",
        "n": "Roma"
    }, {
        "c": "RO",
        "n": "Rovigo"
    }, {
        "c": "SA",
        "n": "Salerno"
    }, {
        "c": "SS",
        "n": "Sassari"
    }, {
        "c": "SV",
        "n": "Savona"
    }, {
        "c": "SI",
        "n": "Siena"
    }, {
        "c": "SR",
        "n": "Siracusa"
    }, {
        "c": "SO",
        "n": "Sondrio"
    }, {
        "c": "TA",
        "n": "Taranto"
    }, {
        "c": "TE",
        "n": "Teramo"
    }, {
        "c": "TR",
        "n": "Terni"
    }, {
        "c": "TO",
        "n": "Torino"
    }, {
        "c": "TP",
        "n": "Trapani"
    }, {
        "c": "TN",
        "n": "Trento"
    }, {
        "c": "TV",
        "n": "Treviso"
    }, {
        "c": "TS",
        "n": "Trieste"
    }, {
        "c": "UD",
        "n": "Udine"
    }, {
        "c": "VA",
        "n": "Varese"
    }, {
        "c": "VE",
        "n": "Venezia"
    }, {
        "c": "VB",
        "n": "Verbano-Cusio-Ossola"
    }, {
        "c": "VC",
        "n": "Vercelli"
    }, {
        "c": "VR",
        "n": "Verona"
    }, {
        "c": "VV",
        "n": "Vibo Valentia"
    }, {
        "c": "VI",
        "n": "Vicenza"
    }, {
        "c": "VT",
        "n": "Viterbo"
    }],
    "JM": [{
        "c": "6",
        "n": "Clarendon"
    }, {
        "c": "1",
        "n": "Hanover"
    }, {
        "c": "11",
        "n": "Kingston"
    }, {
        "c": "7",
        "n": "Manchester"
    }, {
        "c": "12",
        "n": "Portland"
    }, {
        "c": "13",
        "n": "Saint Andrew"
    }, {
        "c": "8",
        "n": "Saint Ann"
    }, {
        "c": "9",
        "n": "Saint Catherine"
    }, {
        "c": "2",
        "n": "Saint Elizabeth"
    }, {
        "c": "3",
        "n": "Saint James"
    }, {
        "c": "10",
        "n": "Saint Mary"
    }, {
        "c": "14",
        "n": "Saint Thomas"
    }, {
        "c": "4",
        "n": "Trelawny"
    }, {
        "c": "5",
        "n": "Westmoreland"
    }],
    "JO": [{
        "c": "AJ",
        "n": "\u0027Ajlūn"
    }, {
        "c": "AM",
        "n": "Amman"
    }, {
        "c": "AT",
        "n": "Aţ Ţafīlah"
    }, {
        "c": "AQ",
        "n": "Al \u0027Aqabah"
    }, {
        "c": "AZ",
        "n": "Az Zarqā\u0027"
    }, {
        "c": "BA",
        "n": "Al Balqā\u0027"
    }, {
        "c": "IR",
        "n": "Irbid"
    }, {
        "c": "JA",
        "n": "Jarash"
    }, {
        "c": "KA",
        "n": "Al Karak"
    }, {
        "c": "MA",
        "n": "Al Mafraq"
    }, {
        "c": "MD",
        "n": "Mādabā"
    }, {
        "c": "MN",
        "n": "Ma\u0027ān"
    }],
    "BB": [{
        "c": "01",
        "n": "Christ Church"
    }, {
        "c": "02",
        "n": "Saint Andrew"
    }, {
        "c": "03",
        "n": "Saint George"
    }, {
        "c": "04",
        "n": "Saint James"
    }, {
        "c": "05",
        "n": "Saint John"
    }, {
        "c": "06",
        "n": "Saint Joseph"
    }, {
        "c": "07",
        "n": "Saint Lucy"
    }, {
        "c": "08",
        "n": "Saint Michael"
    }, {
        "c": "09",
        "n": "Saint Peter"
    }, {
        "c": "10",
        "n": "Saint Philip"
    }, {
        "c": "11",
        "n": "Saint Thomas"
    }],
    "JP": [{
        "c": "23",
        "n": "Aichi"
    }, {
        "c": "05",
        "n": "Akita"
    }, {
        "c": "02",
        "n": "Aomori"
    }, {
        "c": "12",
        "n": "Chiba"
    }, {
        "c": "38",
        "n": "Ehime"
    }, {
        "c": "18",
        "n": "Fukui"
    }, {
        "c": "40",
        "n": "Fukuoka"
    }, {
        "c": "07",
        "n": "Fukushima"
    }, {
        "c": "21",
        "n": "Gifu"
    }, {
        "c": "10",
        "n": "Gunma"
    }, {
        "c": "34",
        "n": "Hiroshima"
    }, {
        "c": "01",
        "n": "Hokkaido"
    }, {
        "c": "28",
        "n": "Hyogo"
    }, {
        "c": "08",
        "n": "Ibaraki"
    }, {
        "c": "17",
        "n": "Ishikawa"
    }, {
        "c": "03",
        "n": "Iwate"
    }, {
        "c": "37",
        "n": "Kagawa"
    }, {
        "c": "46",
        "n": "Kagoshima"
    }, {
        "c": "14",
        "n": "Kanagawa"
    }, {
        "c": "39",
        "n": "Kochi"
    }, {
        "c": "43",
        "n": "Kumamoto"
    }, {
        "c": "26",
        "n": "Kyoto"
    }, {
        "c": "24",
        "n": "Mie"
    }, {
        "c": "04",
        "n": "Miyagi"
    }, {
        "c": "45",
        "n": "Miyazaki"
    }, {
        "c": "20",
        "n": "Nagano"
    }, {
        "c": "42",
        "n": "Nagasaki"
    }, {
        "c": "29",
        "n": "Nara"
    }, {
        "c": "15",
        "n": "Niigata"
    }, {
        "c": "44",
        "n": "Oita"
    }, {
        "c": "33",
        "n": "Okayama"
    }, {
        "c": "47",
        "n": "Okinawa"
    }, {
        "c": "27",
        "n": "Osaka"
    }, {
        "c": "41",
        "n": "Saga"
    }, {
        "c": "11",
        "n": "Saitama"
    }, {
        "c": "25",
        "n": "Shiga"
    }, {
        "c": "32",
        "n": "Shimane"
    }, {
        "c": "22",
        "n": "Shizuoka"
    }, {
        "c": "09",
        "n": "Tochigi"
    }, {
        "c": "36",
        "n": "Tokushima"
    }, {
        "c": "13",
        "n": "Tokyo"
    }, {
        "c": "31",
        "n": "Tottori"
    }, {
        "c": "16",
        "n": "Toyama"
    }, {
        "c": "30",
        "n": "Wakayama"
    }, {
        "c": "06",
        "n": "Yamagata"
    }, {
        "c": "35",
        "n": "Yamaguchi"
    }, {
        "c": "19",
        "n": "Yamanashi"
    }],
    "KE": [{
        "c": "KE-01",
        "n": "Baringo",
        "lsc": "01"
    }, {
        "c": "KE-02",
        "n": "Bomet",
        "lsc": "02"
    }, {
        "c": "KE-03",
        "n": "Bungoma",
        "lsc": "03"
    }, {
        "c": "KE-04",
        "n": "Busia",
        "lsc": "04"
    }, {
        "c": "KE-05",
        "n": "Elgeyo/Marakwet",
        "lsc": "05"
    }, {
        "c": "KE-06",
        "n": "Embu",
        "lsc": "06"
    }, {
        "c": "KE-07",
        "n": "Garissa",
        "lsc": "07"
    }, {
        "c": "KE-08",
        "n": "Homa Bay",
        "lsc": "08"
    }, {
        "c": "KE-09",
        "n": "Isiolo",
        "lsc": "09"
    }, {
        "c": "KE-10",
        "n": "Kajiado",
        "lsc": "10"
    }, {
        "c": "KE-11",
        "n": "Kakamega",
        "lsc": "11"
    }, {
        "c": "KE-12",
        "n": "Kericho",
        "lsc": "12"
    }, {
        "c": "KE-13",
        "n": "Kiambu",
        "lsc": "13"
    }, {
        "c": "KE-14",
        "n": "Kilifi",
        "lsc": "14"
    }, {
        "c": "KE-15",
        "n": "Kirinyaga",
        "lsc": "15"
    }, {
        "c": "KE-16",
        "n": "Kisii",
        "lsc": "16"
    }, {
        "c": "KE-17",
        "n": "Kisumu",
        "lsc": "17"
    }, {
        "c": "KE-18",
        "n": "Kitui",
        "lsc": "18"
    }, {
        "c": "KE-19",
        "n": "Kwale",
        "lsc": "19"
    }, {
        "c": "KE-20",
        "n": "Laikipia",
        "lsc": "20"
    }, {
        "c": "KE-21",
        "n": "Lamu",
        "lsc": "21"
    }, {
        "c": "KE-22",
        "n": "Machakos",
        "lsc": "22"
    }, {
        "c": "KE-23",
        "n": "Makueni",
        "lsc": "23"
    }, {
        "c": "KE-24",
        "n": "Mandera",
        "lsc": "24"
    }, {
        "c": "KE-25",
        "n": "Marsabit",
        "lsc": "25"
    }, {
        "c": "KE-26",
        "n": "Meru",
        "lsc": "26"
    }, {
        "c": "KE-27",
        "n": "Migori",
        "lsc": "27"
    }, {
        "c": "KE-28",
        "n": "Mombasa",
        "lsc": "28"
    }, {
        "c": "KE-29",
        "n": "Murang\u0027a",
        "lsc": "29"
    }, {
        "c": "KE-30",
        "n": "Nairobi City",
        "lsc": "30"
    }, {
        "c": "KE-31",
        "n": "Nakuru",
        "lsc": "31"
    }, {
        "c": "KE-32",
        "n": "Nandi",
        "lsc": "32"
    }, {
        "c": "KE-33",
        "n": "Narok",
        "lsc": "33"
    }, {
        "c": "KE-34",
        "n": "Nyamira",
        "lsc": "34"
    }, {
        "c": "KE-35",
        "n": "Nyandarua",
        "lsc": "35"
    }, {
        "c": "KE-36",
        "n": "Nyeri",
        "lsc": "36"
    }, {
        "c": "KE-37",
        "n": "Samburu",
        "lsc": "37"
    }, {
        "c": "KE-38",
        "n": "Siaya",
        "lsc": "38"
    }, {
        "c": "KE-39",
        "n": "Taita/Taveta",
        "lsc": "39"
    }, {
        "c": "KE-40",
        "n": "Tana River",
        "lsc": "40"
    }, {
        "c": "KE-41",
        "n": "Tharaka-Nithi",
        "lsc": "41"
    }, {
        "c": "KE-42",
        "n": "Trans Nzoia",
        "lsc": "42"
    }, {
        "c": "KE-43",
        "n": "Turkana",
        "lsc": "43"
    }, {
        "c": "KE-44",
        "n": "Uasin Gishu",
        "lsc": "44"
    }, {
        "c": "KE-45",
        "n": "Vihiga",
        "lsc": "45"
    }, {
        "c": "KE-46",
        "n": "Wajir",
        "lsc": "46"
    }, {
        "c": "KE-47",
        "n": "West Pokot",
        "lsc": "47"
    }],
    "KH": [{
        "c": "1",
        "n": "Banteay Mean Chey"
    }, {
        "c": "2",
        "n": "Baat Dambang"
    }, {
        "c": "3",
        "n": "Kampong Chaam"
    }, {
        "c": "4",
        "n": "Kampong Chhnang"
    }, {
        "c": "5",
        "n": "Kampong Spueu"
    }, {
        "c": "6",
        "n": "Kampong Thum"
    }, {
        "c": "7",
        "n": "Kampot"
    }, {
        "c": "8",
        "n": "Kandaal"
    }, {
        "c": "9",
        "n": "Kaoh Kong"
    }, {
        "c": "10",
        "n": "Kracheh"
    }, {
        "c": "11",
        "n": "Mondol Kiri"
    }, {
        "c": "12",
        "n": "Phnom Penh"
    }, {
        "c": "13",
        "n": "Preah Vihear"
    }, {
        "c": "14",
        "n": "Prey Veaeng"
    }, {
        "c": "15",
        "n": "Pousaat"
    }, {
        "c": "16",
        "n": "Rotanak Kiri"
    }, {
        "c": "17",
        "n": "Siem Reab"
    }, {
        "c": "18",
        "n": "Krong Preah Sihanouk"
    }, {
        "c": "19",
        "n": "Stueng Traeng"
    }, {
        "c": "20",
        "n": "Svaay Rieng"
    }, {
        "c": "21",
        "n": "Taakaev"
    }, {
        "c": "22",
        "n": "Otdar Mean Chey"
    }, {
        "c": "23",
        "n": "Krong Kaeb"
    }, {
        "c": "24",
        "n": "Krong Pailin"
    }],
    "KW": [{
        "c": "KW-AH",
        "n": "Al Aḩmadī",
        "lsc": "AH"
    }, {
        "c": "KW-FA",
        "n": "Al Farwānīyah",
        "lsc": "FA"
    }, {
        "c": "KW-JA",
        "n": "Al Jahrā’",
        "lsc": "JA"
    }, {
        "c": "KW-KU",
        "n": "Al ‘Āşimah",
        "lsc": "KU"
    }, {
        "c": "KW-MU",
        "n": "Mubārak al Kabīr",
        "lsc": "MU"
    }, {
        "c": "KW-HA",
        "n": "Ḩawallī",
        "lsc": "HA"
    }],
    "KZ": [{
        "c": "ALA",
        "n": "Almaty"
    }, {
        "c": "AST",
        "n": "Astana"
    }, {
        "c": "ALM",
        "n": "Almatinskaya oblast"
    }, {
        "c": "AKM",
        "n": "Akmolinskaya oblast"
    }, {
        "c": "AKT",
        "n": "Aktyubinskaya oblast"
    }, {
        "c": "ATY",
        "n": "Atyrauskaya oblast"
    }, {
        "c": "VOS",
        "n": "Vostochno-Kazakhstanskaya oblast"
    }, {
        "c": "ZHA",
        "n": "Zhambylskaya oblast"
    }, {
        "c": "ZAP",
        "n": "Zapadno-Kazakhstanskaya oblast"
    }, {
        "c": "KAR",
        "n": "Karagandinskaya oblast"
    }, {
        "c": "KUS",
        "n": "Kostanayskaya oblast"
    }, {
        "c": "KZY",
        "n": "Kyzylordinskaya oblast"
    }, {
        "c": "MAN",
        "n": "Mangistauskaya oblast"
    }, {
        "c": "PAV",
        "n": "Pavlodarskaya oblast"
    }, {
        "c": "SEV",
        "n": "Severo-Kazakhstanskaya oblast"
    }, {
        "c": "SHY",
        "n": "Shymkent"
    }, {
        "c": "YUZ",
        "n": "Yuzhno-Kazakhstankaya oblast"
    }],
    "LB": [{
        "c": "LB-AK",
        "n": "Akkar Governorate",
        "lsc": "AK"
    }, {
        "c": "LB-BH",
        "n": "Baalbek-Hermel Governorate",
        "lsc": "BH"
    }, {
        "c": "LB-BA",
        "n": "Beirut Governorate",
        "lsc": "BA"
    }, {
        "c": "LB-BI",
        "n": "Beqaa Governorate",
        "lsc": "BI"
    }, {
        "c": "LB-JL",
        "n": "Mount Lebanon Governorate",
        "lsc": "JL"
    }, {
        "c": "LB-NA",
        "n": "Nabitieh Governorate",
        "lsc": "NA"
    }, {
        "c": "LB-AS",
        "n": "North Lebanon Governorate",
        "lsc": "AS"
    }, {
        "c": "LB-JA",
        "n": "South Lebanon Governorate",
        "lsc": "JA"
    }],
    "LK": [{
        "c": "LK-1",
        "n": "Western Province",
        "lsc": "1"
    }, {
        "c": "LK-2",
        "n": "Central Province",
        "lsc": "2"
    }, {
        "c": "LK-3",
        "n": "Southern Province",
        "lsc": "3"
    }, {
        "c": "LK-4",
        "n": "Northern Province",
        "lsc": "4"
    }, {
        "c": "LK-5",
        "n": "Eastern Province",
        "lsc": "5"
    }, {
        "c": "LK-6",
        "n": "North Western",
        "lsc": "6"
    }, {
        "c": "LK-7",
        "n": "North Central",
        "lsc": "7"
    }, {
        "c": "LK-8",
        "n": "Uva Province",
        "lsc": "8"
    }, {
        "c": "LK-9",
        "n": "Sabaragamuwa Province",
        "lsc": "9"
    }, {
        "c": "LK-11",
        "n": "Colombo",
        "lsc": "11"
    }, {
        "c": "LK-12",
        "n": "Gampaha",
        "lsc": "12"
    }, {
        "c": "LK-13",
        "n": "Kalutara",
        "lsc": "13"
    }, {
        "c": "LK-21",
        "n": "Kandy",
        "lsc": "21"
    }, {
        "c": "LK-22",
        "n": "Matale",
        "lsc": "22"
    }, {
        "c": "LK-23",
        "n": "Nuwara Eliya",
        "lsc": "23"
    }, {
        "c": "LK-31",
        "n": "Galle",
        "lsc": "31"
    }, {
        "c": "LK-32",
        "n": "Matara",
        "lsc": "32"
    }, {
        "c": "LK-33",
        "n": "Hambantota",
        "lsc": "33"
    }, {
        "c": "LK-41",
        "n": "Jaffna",
        "lsc": "41"
    }, {
        "c": "LK-42",
        "n": "Kilinochchi",
        "lsc": "42"
    }, {
        "c": "LK-43",
        "n": "Mannar",
        "lsc": "43"
    }, {
        "c": "LK-44",
        "n": "Vavuniya",
        "lsc": "44"
    }, {
        "c": "LK-45",
        "n": "Mullaittivu",
        "lsc": "45"
    }, {
        "c": "LK-51",
        "n": "Batticaloa",
        "lsc": "51"
    }, {
        "c": "LK-52",
        "n": "Ampara",
        "lsc": "52"
    }, {
        "c": "LK-53",
        "n": "Trincomalee",
        "lsc": "53"
    }, {
        "c": "LK-61",
        "n": "Kurunegala",
        "lsc": "61"
    }, {
        "c": "LK-62",
        "n": "Puttalam",
        "lsc": "62"
    }, {
        "c": "LK-71",
        "n": "Anuradhapura",
        "lsc": "71"
    }, {
        "c": "LK-72",
        "n": "Polonnaruwa",
        "lsc": "72"
    }, {
        "c": "LK-81",
        "n": "Badulla",
        "lsc": "81"
    }, {
        "c": "LK-82",
        "n": "Monaragala",
        "lsc": "82"
    }, {
        "c": "LK-91",
        "n": "Ratnapura",
        "lsc": "91"
    }, {
        "c": "LK-92",
        "n": "Kegalla",
        "lsc": "92"
    }],
    "LU": [{
        "c": "D",
        "n": "Diekirch"
    }, {
        "c": "G",
        "n": "Grevenmacher"
    }, {
        "c": "L",
        "n": "Luxemburg"
    }],
    "MM": [{
        "c": "07",
        "n": "Ayeyawady"
    }, {
        "c": "02",
        "n": "Bago"
    }, {
        "c": "03",
        "n": "Magway"
    }, {
        "c": "04",
        "n": "Mandalay"
    }, {
        "c": "01",
        "n": "Sagaing"
    }, {
        "c": "05",
        "n": "Taninthayi"
    }, {
        "c": "06",
        "n": "Yangon"
    }, {
        "c": "14",
        "n": "Chin"
    }, {
        "c": "11",
        "n": "Kachin"
    }, {
        "c": "12",
        "n": "Kayah"
    }, {
        "c": "13",
        "n": "Kayin"
    }, {
        "c": "15",
        "n": "Mon"
    }, {
        "c": "16",
        "n": "Rakhine"
    }, {
        "c": "17",
        "n": "Shan"
    }, {
        "c": "18",
        "n": "Nay Pyi Taw"
    }],
    "MA": [{
        "c": "09",
        "n": "Chaouia-Ouardigha"
    }, {
        "c": "10",
        "n": "Doukhala-Abda"
    }, {
        "c": "05",
        "n": "Fès-Boulemane"
    }, {
        "c": "02",
        "n": "Gharb-Chrarda-Beni Hssen"
    }, {
        "c": "08",
        "n": "Grand Casablanca"
    }, {
        "c": "14",
        "n": "Guelmim-Es Semara"
    }, {
        "c": "15",
        "n": "Laâyoune-Boujdour-Sakia el Hamra"
    }, {
        "c": "04",
        "n": "L\u0027Oriental"
    }, {
        "c": "11",
        "n": "Marrakech-Tensift-Al Haouz"
    }, {
        "c": "06",
        "n": "Meknès-Tafilalet"
    }, {
        "c": "16",
        "n": "Oued ed Dahab-Lagouira"
    }, {
        "c": "07",
        "n": "Rabat-Salé-Zemmour-Zaer"
    }, {
        "c": "13",
        "n": "Souss-Massa-Drâa"
    }, {
        "c": "12",
        "n": "Tadla-Azilal"
    }, {
        "c": "01",
        "n": "Tanger-Tétouan"
    }, {
        "c": "03",
        "n": "Taza-Al Hoceima-Taounate"
    }],
    "MX": [{
        "c": "AGU",
        "n": "Aguascalientes"
    }, {
        "c": "BCN",
        "n": "Baja California"
    }, {
        "c": "BCS",
        "n": "Baja California Sur"
    }, {
        "c": "CAM",
        "n": "Campeche"
    }, {
        "c": "CHP",
        "n": "Chiapas"
    }, {
        "c": "CHH",
        "n": "Chihuahua"
    }, {
        "c": "COA",
        "n": "Coahuila"
    }, {
        "c": "COL",
        "n": "Colima"
    }, {
        "c": "CMX",
        "n": "Ciudad de México"
    }, {
        "c": "DUR",
        "n": "Durango"
    }, {
        "c": "GUA",
        "n": "Guanajuato"
    }, {
        "c": "GRO",
        "n": "Guerrero"
    }, {
        "c": "HID",
        "n": "Hidalgo"
    }, {
        "c": "JAL",
        "n": "Jalisco"
    }, {
        "c": "MEX",
        "n": "México"
    }, {
        "c": "MIC",
        "n": "Michoacán"
    }, {
        "c": "MOR",
        "n": "Morelos"
    }, {
        "c": "NAY",
        "n": "Nayarit"
    }, {
        "c": "NLE",
        "n": "Nuevo León"
    }, {
        "c": "OAX",
        "n": "Oaxaca"
    }, {
        "c": "PUE",
        "n": "Puebla"
    }, {
        "c": "QUE",
        "n": "Querétaro"
    }, {
        "c": "ROO",
        "n": "Quintana Roo"
    }, {
        "c": "SLP",
        "n": "San Luis Potosí"
    }, {
        "c": "SIN",
        "n": "Sinaloa"
    }, {
        "c": "SON",
        "n": "Sonora"
    }, {
        "c": "TAB",
        "n": "Tabasco"
    }, {
        "c": "TAM",
        "n": "Tamaulipas"
    }, {
        "c": "TLA",
        "n": "Tlaxcala"
    }, {
        "c": "VER",
        "n": "Veracruz"
    }, {
        "c": "YUC",
        "n": "Yucatán"
    }, {
        "c": "ZAC",
        "n": "Zacatecas"
    }],
    "MY": [{
        "c": "MY-01",
        "n": "Johor",
        "lsc": "01"
    }, {
        "c": "MY-02",
        "n": "Kedah",
        "lsc": "02"
    }, {
        "c": "MY-03",
        "n": "Kelantan",
        "lsc": "03"
    }, {
        "c": "MY-04",
        "n": "Malacca",
        "lsc": "04"
    }, {
        "c": "MY-05",
        "n": "Negeri Sembilan",
        "lsc": "05"
    }, {
        "c": "MY-06",
        "n": "Pahang",
        "lsc": "06"
    }, {
        "c": "MY-08",
        "n": "Perak",
        "lsc": "08"
    }, {
        "c": "MY-09",
        "n": "Perlis",
        "lsc": "09"
    }, {
        "c": "MY-07",
        "n": "Penang",
        "lsc": "07"
    }, {
        "c": "MY-12",
        "n": "Sabah",
        "lsc": "12"
    }, {
        "c": "MY-13",
        "n": "Sarawak",
        "lsc": "13"
    }, {
        "c": "MY-10",
        "n": "Selangor",
        "lsc": "10"
    }, {
        "c": "MY-11",
        "n": "Terengganu",
        "lsc": "11"
    }, {
        "c": "MY-14",
        "n": "Kuala Lumpur",
        "lsc": "14"
    }, {
        "c": "MY-15",
        "n": "Labuan",
        "lsc": "15"
    }, {
        "c": "MY-16",
        "n": "Putrajaya",
        "lsc": "16"
    }],
    "NG": [{
        "c": "FC",
        "n": "Abuja"
    }, {
        "c": "AB",
        "n": "Abia"
    }, {
        "c": "AD",
        "n": "Adamawa"
    }, {
        "c": "AK",
        "n": "Akwa Ibom"
    }, {
        "c": "AN",
        "n": "Anambra"
    }, {
        "c": "BA",
        "n": "Bauchi"
    }, {
        "c": "BY",
        "n": "Bayelsa"
    }, {
        "c": "BE",
        "n": "Benue"
    }, {
        "c": "BO",
        "n": "Borno"
    }, {
        "c": "CR",
        "n": "Cross River"
    }, {
        "c": "DE",
        "n": "Delta"
    }, {
        "c": "EB",
        "n": "Ebonyi"
    }, {
        "c": "ED",
        "n": "Edo"
    }, {
        "c": "EK",
        "n": "Ekiti"
    }, {
        "c": "EN",
        "n": "Enugu"
    }, {
        "c": "GO",
        "n": "Gombe"
    }, {
        "c": "IM",
        "n": "Imo"
    }, {
        "c": "JI",
        "n": "Jigawa"
    }, {
        "c": "KD",
        "n": "Kaduna"
    }, {
        "c": "KN",
        "n": "Kano"
    }, {
        "c": "KT",
        "n": "Katsina"
    }, {
        "c": "KE",
        "n": "Kebbi"
    }, {
        "c": "KO",
        "n": "Kogi"
    }, {
        "c": "KW",
        "n": "Kwara"
    }, {
        "c": "LA",
        "n": "Lagos"
    }, {
        "c": "NA",
        "n": "Nassarawa"
    }, {
        "c": "NI",
        "n": "Niger"
    }, {
        "c": "OG",
        "n": "Ogun"
    }, {
        "c": "ON",
        "n": "Ondo"
    }, {
        "c": "OS",
        "n": "Osun"
    }, {
        "c": "OY",
        "n": "Oyo"
    }, {
        "c": "PL",
        "n": "Plateau"
    }, {
        "c": "RI",
        "n": "Rivers"
    }, {
        "c": "SO",
        "n": "Sokoto"
    }, {
        "c": "TA",
        "n": "Taraba"
    }, {
        "c": "YO",
        "n": "Yobe"
    }, {
        "c": "ZA",
        "n": "Zamfara"
    }],
    "NL": [{
        "c": "DRE",
        "n": "Drenthe"
    }, {
        "c": "FLE",
        "n": "Flevoland"
    }, {
        "c": "FRI",
        "n": "Friesland"
    }, {
        "c": "GEL",
        "n": "Gelderland"
    }, {
        "c": "GRO",
        "n": "Groningen"
    }, {
        "c": "LIM",
        "n": "Limburg"
    }, {
        "c": "NBR",
        "n": "Noord-Brabant"
    }, {
        "c": "NHO",
        "n": "Noord-Holland"
    }, {
        "c": "OVE",
        "n": "Overijssel"
    }, {
        "c": "UTR",
        "n": "Utrecht"
    }, {
        "c": "ZEE",
        "n": "Zeeland"
    }, {
        "c": "ZHO",
        "n": "Zuid-Holland"
    }],
    "NO": [{
        "c": "42",
        "n": "Agder"
    }, {
        "c": "34",
        "n": "Innlandet"
    }, {
        "c": "15",
        "n": "Møre og Romsdal"
    }, {
        "c": "18",
        "n": "Nordland"
    }, {
        "c": "03",
        "n": "Oslo"
    }, {
        "c": "11",
        "n": "Rogaland"
    }, {
        "c": "50",
        "n": "Trøndelag"
    }, {
        "c": "54",
        "n": "Troms og Finnmark"
    }, {
        "c": "30",
        "n": "Viken"
    }, {
        "c": "38",
        "n": "Vestfold og Telemark"
    }, {
        "c": "46",
        "n": "Vestland"
    }],
    "NZ": [{
        "c": "NTL",
        "n": "Northland"
    }, {
        "c": "AUK",
        "n": "Auckland"
    }, {
        "c": "WKO",
        "n": "Waikato"
    }, {
        "c": "BOP",
        "n": "Bay of Plenty"
    }, {
        "c": "GIS",
        "n": "East Cape"
    }, {
        "c": "HKB",
        "n": "Hawke\u0027s Bay"
    }, {
        "c": "TKI",
        "n": "Taranaki"
    }, {
        "c": "MWT",
        "n": "Manawatu-Wanganui"
    }, {
        "c": "WGN",
        "n": "Wellington"
    }, {
        "c": "TAS",
        "n": "Tasman"
    }, {
        "c": "NSN",
        "n": "Nelson"
    }, {
        "c": "MBH",
        "n": "Marlborough"
    }, {
        "c": "WTC",
        "n": "West Coast"
    }, {
        "c": "CAN",
        "n": "Canterbury"
    }, {
        "c": "OTA",
        "n": "Otago"
    }, {
        "c": "STL",
        "n": "Southland"
    }],
    "OM": [{
        "c": "DA",
        "n": "Ad Dākhilīyah"
    }, {
        "c": "BS",
        "n": "Shamāl al Bāţinah"
    }, {
        "c": "BJ",
        "n": "Janūb al Bāţinah"
    }, {
        "c": "WU",
        "n": "Al Wusţá"
    }, {
        "c": "SS",
        "n": "Shamāl ash Sharqīyah"
    }, {
        "c": "SJ",
        "n": "Janūb ash Sharqīyah"
    }, {
        "c": "ZA",
        "n": "Az̧ Z̧āhirah"
    }, {
        "c": "BU",
        "n": "Al Buraymī"
    }, {
        "c": "MA",
        "n": "Masqaţ"
    }, {
        "c": "MU",
        "n": "Musandam"
    }, {
        "c": "ZU",
        "n": "Z̧ufār"
    }],
    "PA": [{
        "c": "1",
        "n": "Bocas del Toro"
    }, {
        "c": "2",
        "n": "Coclé"
    }, {
        "c": "3",
        "n": "Colón"
    }, {
        "c": "4",
        "n": "Chiriquí"
    }, {
        "c": "5",
        "n": "Darién"
    }, {
        "c": "6",
        "n": "Herrera"
    }, {
        "c": "7",
        "n": "Los Santos"
    }, {
        "c": "8",
        "n": "Panamá"
    }, {
        "c": "9",
        "n": "Veraguas"
    }, {
        "c": "10",
        "n": "Panamá Oeste"
    }, {
        "c": "EM",
        "n": "Emberá"
    }, {
        "c": "KY",
        "n": "Guna Yala"
    }, {
        "c": "NB",
        "n": "Ngöbe-Buglé"
    }],
    "PE": [{
        "c": "AMA",
        "n": "Amazonas"
    }, {
        "c": "ANC",
        "n": "Ancash"
    }, {
        "c": "APU",
        "n": "Apurímac"
    }, {
        "c": "ARE",
        "n": "Arequipa"
    }, {
        "c": "AYA",
        "n": "Ayacucho"
    }, {
        "c": "CAJ",
        "n": "Cajamarca"
    }, {
        "c": "CAL",
        "n": "Callao"
    }, {
        "c": "CUS",
        "n": "Cusco"
    }, {
        "c": "HUV",
        "n": "Huancavelica"
    }, {
        "c": "HUC",
        "n": "Huánuco"
    }, {
        "c": "ICA",
        "n": "Ica"
    }, {
        "c": "JUN",
        "n": "Junín"
    }, {
        "c": "LAL",
        "n": "La Libertad"
    }, {
        "c": "LAM",
        "n": "Lambayeque"
    }, {
        "c": "LIM",
        "n": "Lima"
    }, {
        "c": "LOR",
        "n": "Loreto"
    }, {
        "c": "MDD",
        "n": "Madre de Dios"
    }, {
        "c": "MOQ",
        "n": "Moquegua"
    }, {
        "c": "PAS",
        "n": "Pasco"
    }, {
        "c": "PIU",
        "n": "Piura"
    }, {
        "c": "PUN",
        "n": "Puno"
    }, {
        "c": "SAM",
        "n": "San Martín"
    }, {
        "c": "TAC",
        "n": "Tacna"
    }, {
        "c": "TUM",
        "n": "Tumbes"
    }, {
        "c": "UCA",
        "n": "Ucayali"
    }],
    "PF": [{
        "c": "01",
        "n": "Ahe"
    }, {
        "c": "02",
        "n": "Amanu"
    }, {
        "c": "03",
        "n": "Anaa"
    }, {
        "c": "04",
        "n": "Apataki"
    }, {
        "c": "05",
        "n": "Arutua"
    }, {
        "c": "06",
        "n": "Bora Bora"
    }, {
        "c": "07",
        "n": "Faaite"
    }, {
        "c": "08",
        "n": "Fakahina"
    }, {
        "c": "09",
        "n": "Fakarava"
    }, {
        "c": "10",
        "n": "Fangatau"
    }, {
        "c": "11",
        "n": "Fatu Hiva"
    }, {
        "c": "12",
        "n": "Hao"
    }, {
        "c": "13",
        "n": "Hikueru"
    }, {
        "c": "14",
        "n": "Hiva Oa"
    }, {
        "c": "15",
        "n": "Huahine"
    }, {
        "c": "16",
        "n": "Katiu"
    }, {
        "c": "17",
        "n": "Kauehi"
    }, {
        "c": "18",
        "n": "Kaukura"
    }, {
        "c": "19",
        "n": "Makemo"
    }, {
        "c": "20",
        "n": "Mangareva"
    }, {
        "c": "21",
        "n": "Manihi"
    }, {
        "c": "22",
        "n": "Mataiva"
    }, {
        "c": "23",
        "n": "Maupiti"
    }, {
        "c": "24",
        "n": "Moorea"
    }, {
        "c": "25",
        "n": "Napuka"
    }, {
        "c": "26",
        "n": "Nuku Hiva"
    }, {
        "c": "27",
        "n": "Nukutavake"
    }, {
        "c": "28",
        "n": "Puka Puka"
    }, {
        "c": "29",
        "n": "Pukarua"
    }, {
        "c": "30",
        "n": "Raivarae"
    }, {
        "c": "31",
        "n": "Rangiroa"
    }, {
        "c": "32",
        "n": "Rapa"
    }, {
        "c": "33",
        "n": "Raroia"
    }, {
        "c": "34",
        "n": "Reao"
    }, {
        "c": "35",
        "n": "Raiatea"
    }, {
        "c": "36",
        "n": "Rimatara"
    }, {
        "c": "37",
        "n": "Rurutu"
    }, {
        "c": "38",
        "n": "Taenga"
    }, {
        "c": "39",
        "n": "Tahaa"
    }, {
        "c": "40",
        "n": "Tahiti"
    }, {
        "c": "41",
        "n": "Tahuata"
    }, {
        "c": "42",
        "n": "Takapoto"
    }, {
        "c": "43",
        "n": "Takaroa"
    }, {
        "c": "44",
        "n": "Takume"
    }, {
        "c": "45",
        "n": "Tatakoto"
    }, {
        "c": "46",
        "n": "Tikehau"
    }, {
        "c": "47",
        "n": "Tubuai"
    }, {
        "c": "48",
        "n": "Tureia"
    }, {
        "c": "49",
        "n": "Uahuka"
    }, {
        "c": "50",
        "n": "Uapou"
    }, {
        "c": "51",
        "n": "Vahitahi"
    }],
    "PH": [{
        "c": "ABR",
        "n": "Abra"
    }, {
        "c": "AGN",
        "n": "Agusan del Norte"
    }, {
        "c": "AGS",
        "n": "Agusan del Sur"
    }, {
        "c": "AKL",
        "n": "Aklan"
    }, {
        "c": "ALB",
        "n": "Albay"
    }, {
        "c": "ANT",
        "n": "Antique"
    }, {
        "c": "APA",
        "n": "Apayao"
    }, {
        "c": "AUR",
        "n": "Aurora"
    }, {
        "c": "BAS",
        "n": "Basilan"
    }, {
        "c": "BAN",
        "n": "Bataan"
    }, {
        "c": "BTN",
        "n": "Batanes"
    }, {
        "c": "BTG",
        "n": "Batangas"
    }, {
        "c": "BEN",
        "n": "Benguet"
    }, {
        "c": "BIL",
        "n": "Biliran"
    }, {
        "c": "BOH",
        "n": "Bohol"
    }, {
        "c": "BUK",
        "n": "Bukidnon"
    }, {
        "c": "BUL",
        "n": "Bulacan"
    }, {
        "c": "CAG",
        "n": "Cagayan"
    }, {
        "c": "CAN",
        "n": "Camarines Norte"
    }, {
        "c": "CAS",
        "n": "Camarines Sur"
    }, {
        "c": "CAM",
        "n": "Camiguin"
    }, {
        "c": "CAP",
        "n": "Capiz"
    }, {
        "c": "CAT",
        "n": "Catanduanes"
    }, {
        "c": "CAV",
        "n": "Cavite"
    }, {
        "c": "CEB",
        "n": "Cebu"
    }, {
        "c": "COM",
        "n": "Compostela Valley"
    }, {
        "c": "NCO",
        "n": "North Cotabato"
    }, {
        "c": "DAV",
        "n": "Davao del Norte"
    }, {
        "c": "DAS",
        "n": "Davao del Sur"
    }, {
        "c": "DVO",
        "n": "Davao Occidental"
    }, {
        "c": "DAO",
        "n": "Davao Oriental"
    }, {
        "c": "DIN",
        "n": "Dinagat Islands"
    }, {
        "c": "EAS",
        "n": "Eastern Samar"
    }, {
        "c": "GUI",
        "n": "Guimaras"
    }, {
        "c": "IFU",
        "n": "Ifugao"
    }, {
        "c": "ILN",
        "n": "Ilocos Norte"
    }, {
        "c": "ILS",
        "n": "Ilocos Sur"
    }, {
        "c": "ILI",
        "n": "Iloilo"
    }, {
        "c": "ISA",
        "n": "Isabela"
    }, {
        "c": "KAL",
        "n": "Kalinga"
    }, {
        "c": "LUN",
        "n": "La Union"
    }, {
        "c": "LAG",
        "n": "Laguna"
    }, {
        "c": "LAN",
        "n": "Lanao del Norte"
    }, {
        "c": "LAS",
        "n": "Lanao del Sur"
    }, {
        "c": "LEY",
        "n": "Leyte"
    }, {
        "c": "MAG",
        "n": "Maguindanao"
    }, {
        "c": "MAD",
        "n": "Marinduque"
    }, {
        "c": "MAS",
        "n": "Masbate"
    }, {
        "c": "MDC",
        "n": "Mindoro Occidental"
    }, {
        "c": "MDR",
        "n": "Mindoro Oriental"
    }, {
        "c": "MNL",
        "n": "Metro Manila"
    }, {
        "c": "MSC",
        "n": "Misamis Occidental"
    }, {
        "c": "MSR",
        "n": "Misamis Oriental"
    }, {
        "c": "MOU",
        "n": "Mountain Province"
    }, {
        "c": "NEC",
        "n": "Negros Occidental"
    }, {
        "c": "NER",
        "n": "Negros Oriental"
    }, {
        "c": "NSA",
        "n": "Northern Samar"
    }, {
        "c": "NUE",
        "n": "Nueva Ecija"
    }, {
        "c": "NUV",
        "n": "Nueva Vizcaya"
    }, {
        "c": "PLW",
        "n": "Palawan"
    }, {
        "c": "PAM",
        "n": "Pampanga"
    }, {
        "c": "PAN",
        "n": "Pangasinan"
    }, {
        "c": "QUE",
        "n": "Quezon"
    }, {
        "c": "QUI",
        "n": "Quirino"
    }, {
        "c": "RIZ",
        "n": "Rizal"
    }, {
        "c": "ROM",
        "n": "Romblon"
    }, {
        "c": "WSA",
        "n": "Samar (Western Samar)"
    }, {
        "c": "SAR",
        "n": "Sarangani"
    }, {
        "c": "SIG",
        "n": "Siquijor"
    }, {
        "c": "SOR",
        "n": "Sorsogon"
    }, {
        "c": "SCO",
        "n": "South Cotabato"
    }, {
        "c": "SLE",
        "n": "Southern Leyte"
    }, {
        "c": "SUK",
        "n": "Sultan Kudarat"
    }, {
        "c": "SLU",
        "n": "Sulu"
    }, {
        "c": "SUN",
        "n": "Surigao del Norte"
    }, {
        "c": "SUR",
        "n": "Surigao del Sur"
    }, {
        "c": "TAR",
        "n": "Tarlac"
    }, {
        "c": "TAW",
        "n": "Tawi-Tawi"
    }, {
        "c": "ZMB",
        "n": "Zambales"
    }, {
        "c": "ZAN",
        "n": "Zamboanga del Norte"
    }, {
        "c": "ZAS",
        "n": "Zamboanga del Sur"
    }, {
        "c": "ZSI",
        "n": "Zamboanga Sibugay"
    }],
    "PK": [{
        "c": "IS",
        "n": "Islamabad"
    }, {
        "c": "BA",
        "n": "Balochistan"
    }, {
        "c": "KP",
        "n": "Khyber Pakhtunkhwa"
    }, {
        "c": "PB",
        "n": "Punjab"
    }, {
        "c": "SD",
        "n": "Sindh"
    }, {
        "c": "JK",
        "n": "Azad Jammu and Kashmir"
    }, {
        "c": "GB",
        "n": "Gilgit-Baltistan"
    }],
    "PL": [{
        "c": "DS",
        "n": "Lower Silesia"
    }, {
        "c": "KP",
        "n": "Kuyavia-Pomerania"
    }, {
        "c": "LU",
        "n": "Lublin"
    }, {
        "c": "LB",
        "n": "Lubusz"
    }, {
        "c": "LD",
        "n": "Łódź"
    }, {
        "c": "MA",
        "n": "Lesser Poland"
    }, {
        "c": "MZ",
        "n": "Mazovia"
    }, {
        "c": "OP",
        "n": "Opole (Upper Silesia)"
    }, {
        "c": "PK",
        "n": "Subcarpathia"
    }, {
        "c": "PD",
        "n": "Podlaskie"
    }, {
        "c": "PM",
        "n": "Pomerania"
    }, {
        "c": "SL",
        "n": "Silesia"
    }, {
        "c": "SK",
        "n": "Holy Cross"
    }, {
        "c": "WN",
        "n": "Warmia-Masuria"
    }, {
        "c": "WP",
        "n": "Greater Poland"
    }, {
        "c": "ZP",
        "n": "West Pomerania"
    }],
    "PT": [{
        "c": "19",
        "n": "Açores"
    }, {
        "c": "12",
        "n": "Aveiro"
    }, {
        "c": "5",
        "n": "Beja"
    }, {
        "c": "17",
        "n": "Braga"
    }, {
        "c": "14",
        "n": "Bragança"
    }, {
        "c": "9",
        "n": "Castelo Branco"
    }, {
        "c": "11",
        "n": "Coimbra"
    }, {
        "c": "10",
        "n": "Guarda"
    }, {
        "c": "7",
        "n": "Évora"
    }, {
        "c": "6",
        "n": "Faro"
    }, {
        "c": "2",
        "n": "Leiria"
    }, {
        "c": "1",
        "n": "Lisboa"
    }, {
        "c": "20",
        "n": "Madeira"
    }, {
        "c": "8",
        "n": "Portalegre"
    }, {
        "c": "16",
        "n": "Porto"
    }, {
        "c": "3",
        "n": "Santarém"
    }, {
        "c": "4",
        "n": "Setúbal"
    }, {
        "c": "18",
        "n": "Viana do Castelo"
    }, {
        "c": "15",
        "n": "Vila Real"
    }, {
        "c": "13",
        "n": "Viseu"
    }],
    "PY": [{
        "c": "ASU",
        "n": "Asunción"
    }, {
        "c": "16",
        "n": "Alto Paraguay"
    }, {
        "c": "10",
        "n": "Alto Paraná"
    }, {
        "c": "13",
        "n": "Amambay"
    }, {
        "c": "19",
        "n": "Boquerón"
    }, {
        "c": "5",
        "n": "Caaguazú"
    }, {
        "c": "6",
        "n": "Caazapá"
    }, {
        "c": "14",
        "n": "Canindeyú"
    }, {
        "c": "11",
        "n": "Central"
    }, {
        "c": "1",
        "n": "Concepción"
    }, {
        "c": "3",
        "n": "Cordillera"
    }, {
        "c": "4",
        "n": "Guairá"
    }, {
        "c": "7",
        "n": "Itapúa"
    }, {
        "c": "8",
        "n": "Misiones"
    }, {
        "c": "12",
        "n": "Ñeembucú"
    }, {
        "c": "9",
        "n": "Paraguarí"
    }, {
        "c": "15",
        "n": "Presidente Hayes"
    }, {
        "c": "2",
        "n": "San Pedro"
    }],
    "RO": [{
        "c": "AB",
        "n": "Alba"
    }, {
        "c": "AR",
        "n": "Arad"
    }, {
        "c": "AG",
        "n": "Argeş"
    }, {
        "c": "BC",
        "n": "Bacău"
    }, {
        "c": "BH",
        "n": "Bihor"
    }, {
        "c": "BN",
        "n": "Bistriţa-Năsăud"
    }, {
        "c": "BT",
        "n": "Botoşani"
    }, {
        "c": "BR",
        "n": "Brăila"
    }, {
        "c": "BV",
        "n": "Braşov"
    }, {
        "c": "B",
        "n": "Bucureşti"
    }, {
        "c": "BZ",
        "n": "Buzău"
    }, {
        "c": "CL",
        "n": "Călăraşi"
    }, {
        "c": "CS",
        "n": "Caraş-Severin"
    }, {
        "c": "CJ",
        "n": "Cluj"
    }, {
        "c": "CT",
        "n": "Constanţa"
    }, {
        "c": "CV",
        "n": "Covasna"
    }, {
        "c": "DB",
        "n": "Dâmboviţa"
    }, {
        "c": "DJ",
        "n": "Dolj"
    }, {
        "c": "GL",
        "n": "Galaţi"
    }, {
        "c": "GR",
        "n": "Giurgiu"
    }, {
        "c": "GJ",
        "n": "Gorj"
    }, {
        "c": "HR",
        "n": "Harghita"
    }, {
        "c": "HD",
        "n": "Hunedoara"
    }, {
        "c": "IL",
        "n": "Ialomiţa"
    }, {
        "c": "IS",
        "n": "Iaşi"
    }, {
        "c": "IF",
        "n": "Ilfov"
    }, {
        "c": "MM",
        "n": "Maramureş"
    }, {
        "c": "MH",
        "n": "Mehedinţi"
    }, {
        "c": "MS",
        "n": "Mureş"
    }, {
        "c": "NT",
        "n": "Neamţ"
    }, {
        "c": "OT",
        "n": "Olt"
    }, {
        "c": "PH",
        "n": "Prahova"
    }, {
        "c": "SJ",
        "n": "Sălaj"
    }, {
        "c": "SM",
        "n": "Satu Mare"
    }, {
        "c": "SB",
        "n": "Sibiu"
    }, {
        "c": "SV",
        "n": "Suceava"
    }, {
        "c": "TR",
        "n": "Teleorman"
    }, {
        "c": "TM",
        "n": "Timiş"
    }, {
        "c": "TL",
        "n": "Tulcea"
    }, {
        "c": "VL",
        "n": "Vâlcea"
    }, {
        "c": "VS",
        "n": "Vaslui"
    }, {
        "c": "VN",
        "n": "Vrancea"
    }],
    "RU": [{
        "c": "77",
        "n": "Moscow",
        "useAsCityName": true,
        "noUseSort": true
    }, {
        "c": "50",
        "n": "Moskovskaya oblast",
        "noUseSort": true
    }, {
        "c": "78",
        "n": "Saint Petersburg",
        "useAsCityName": true,
        "noUseSort": true
    }, {
        "c": "47",
        "n": "Leningradskaya oblast",
        "noUseSort": true
    }, {
        "c": "1",
        "n": "Adygeya Republic"
    }, {
        "c": "2",
        "n": "Bashkortostan Republic"
    }, {
        "c": "3",
        "n": "Buryatiya Republic"
    }, {
        "c": "4",
        "n": "Altay Republic"
    }, {
        "c": "5",
        "n": "Dagestan Republic"
    }, {
        "c": "6",
        "n": "Ingushetiya Republic"
    }, {
        "c": "7",
        "n": "Kabardino-Balkariya Republic"
    }, {
        "c": "8",
        "n": "Kalmykiya Republic"
    }, {
        "c": "9",
        "n": "Karachayevo-Cherkesiya Republic"
    }, {
        "c": "10",
        "n": "Kareliya Republic"
    }, {
        "c": "11",
        "n": "Komi Republic"
    }, {
        "c": "12",
        "n": "Mariy-El Republic"
    }, {
        "c": "13",
        "n": "Mordoviya Republic"
    }, {
        "c": "14",
        "n": "Sakha (Yakutiya) Republic"
    }, {
        "c": "15",
        "n": "Severnaya Osetiya-Alaniya Republic"
    }, {
        "c": "16",
        "n": "Tatarstan Republic"
    }, {
        "c": "17",
        "n": "Tyva Republic"
    }, {
        "c": "18",
        "n": "Udmurtiya Republic"
    }, {
        "c": "19",
        "n": "Khakasiya Republic"
    }, {
        "c": "20",
        "n": "Chechnya Republic"
    }, {
        "c": "21",
        "n": "Chuvashiya Republic"
    }, {
        "c": "22",
        "n": "Altayskiy kray"
    }, {
        "c": "23",
        "n": "Krasnodarskiy kray"
    }, {
        "c": "24",
        "n": "Krasnoyarskiy kray"
    }, {
        "c": "25",
        "n": "Primorskiy kray"
    }, {
        "c": "26",
        "n": "Stavropolskiy kray"
    }, {
        "c": "27",
        "n": "Khabarovskiy kray"
    }, {
        "c": "28",
        "n": "Amurskaya oblast"
    }, {
        "c": "29",
        "n": "Arkhangelskaya oblast"
    }, {
        "c": "30",
        "n": "Astrakhanskaya oblast"
    }, {
        "c": "31",
        "n": "Belgorodskaya oblast"
    }, {
        "c": "32",
        "n": "Bryanskaya oblast"
    }, {
        "c": "33",
        "n": "Vladimirskaya oblast"
    }, {
        "c": "34",
        "n": "Volgogradskaya oblast"
    }, {
        "c": "35",
        "n": "Vologodskaya oblast"
    }, {
        "c": "36",
        "n": "Voronezhskaya oblast"
    }, {
        "c": "37",
        "n": "Ivanovskaya oblast"
    }, {
        "c": "38",
        "n": "Irkutskaya oblast"
    }, {
        "c": "39",
        "n": "Kaliningradskaya oblast"
    }, {
        "c": "40",
        "n": "Kaluzhskaya oblast"
    }, {
        "c": "41",
        "n": "Kamchatskiy kray"
    }, {
        "c": "42",
        "n": "Kemerovskaya oblast"
    }, {
        "c": "43",
        "n": "Kirovskaya oblast"
    }, {
        "c": "44",
        "n": "Kostromskaya oblast"
    }, {
        "c": "45",
        "n": "Kurganskaya oblast"
    }, {
        "c": "46",
        "n": "Kurskaya oblast"
    }, {
        "c": "48",
        "n": "Lipetskaya oblast"
    }, {
        "c": "49",
        "n": "Magadanskaya oblast"
    }, {
        "c": "51",
        "n": "Murmanskaya oblast"
    }, {
        "c": "52",
        "n": "Nizhegorodskaya oblast"
    }, {
        "c": "53",
        "n": "Novgorodskaya oblast"
    }, {
        "c": "54",
        "n": "Novosibirskaya oblast"
    }, {
        "c": "55",
        "n": "Omskaya oblast"
    }, {
        "c": "56",
        "n": "Orenburgskaya oblast"
    }, {
        "c": "57",
        "n": "Orlovskaya oblast"
    }, {
        "c": "58",
        "n": "Penzenskaya oblast"
    }, {
        "c": "59",
        "n": "Permskiy kray"
    }, {
        "c": "60",
        "n": "Pskovskaya oblast"
    }, {
        "c": "61",
        "n": "Rostovskaya oblast"
    }, {
        "c": "62",
        "n": "Ryazanskaya oblast"
    }, {
        "c": "63",
        "n": "Samarskaya oblast"
    }, {
        "c": "64",
        "n": "Saratovskaya oblast"
    }, {
        "c": "65",
        "n": "Sakhalinskaya oblast"
    }, {
        "c": "66",
        "n": "Sverdlovskaya oblast"
    }, {
        "c": "67",
        "n": "Smolenskaya oblast"
    }, {
        "c": "68",
        "n": "Tambovskaya oblast"
    }, {
        "c": "69",
        "n": "Tverskaya oblast"
    }, {
        "c": "70",
        "n": "Tomskaya oblast"
    }, {
        "c": "71",
        "n": "Tulskaya oblast"
    }, {
        "c": "72",
        "n": "Tyumenskaya oblast"
    }, {
        "c": "73",
        "n": "Ulyanovskaya oblast"
    }, {
        "c": "74",
        "n": "Chelyabinskaya oblast"
    }, {
        "c": "75",
        "n": "Zabaykalskiy kray"
    }, {
        "c": "76",
        "n": "Yaroslavskaya oblast"
    }, {
        "c": "79",
        "n": "Yevreyskaya avtonomnaya oblast"
    }, {
        "c": "83",
        "n": "Nenetskiy avtonomnyy okrug"
    }, {
        "c": "86",
        "n": "Khanty-Mansiyskiy avtonomnyy okrug"
    }, {
        "c": "87",
        "n": "Chukotskiy avtonomnyy okrug"
    }, {
        "c": "89",
        "n": "Yamalo-Nenetskiy avtonomnyy okrug"
    }, {
        "c": "94",
        "n": "Baykonur",
        "useAsCityName": true
    }],
    "SA": [{
        "c": "11",
        "n": "Al Bāḩah"
    }, {
        "c": "08",
        "n": "Al Ḩudūd ash Shamālīyah"
    }, {
        "c": "12",
        "n": "Al Jawf"
    }, {
        "c": "03",
        "n": "Al Madīnah"
    }, {
        "c": "05",
        "n": "Al Qaşīm"
    }, {
        "c": "01",
        "n": "Ar Riyāḑ"
    }, {
        "c": "04",
        "n": "Ash Sharqīyah"
    }, {
        "c": "14",
        "n": "ٰĀsīr"
    }, {
        "c": "06",
        "n": "Ḩā\u0027il"
    }, {
        "c": "09",
        "n": "Jīzān"
    }, {
        "c": "02",
        "n": "Makkah"
    }, {
        "c": "10",
        "n": "Najrān"
    }, {
        "c": "07",
        "n": "Tabūk"
    }],
    "SE": [{
        "c": "K",
        "n": "Blekinge"
    }, {
        "c": "W",
        "n": "Dalarna"
    }, {
        "c": "I",
        "n": "Gotlands"
    }, {
        "c": "X",
        "n": "Gävleborg"
    }, {
        "c": "N",
        "n": "Halland"
    }, {
        "c": "Z",
        "n": "Jämtland"
    }, {
        "c": "F",
        "n": "Jönköping"
    }, {
        "c": "H",
        "n": "Kalmar"
    }, {
        "c": "G",
        "n": "Kronoberg"
    }, {
        "c": "BD",
        "n": "Norrbotten"
    }, {
        "c": "M",
        "n": "Skåne"
    }, {
        "c": "AB",
        "n": "Stockholm"
    }, {
        "c": "D",
        "n": "Södermanland"
    }, {
        "c": "C",
        "n": "Uppsala"
    }, {
        "c": "S",
        "n": "Värmland"
    }, {
        "c": "AC",
        "n": "Västerbotten"
    }, {
        "c": "Y",
        "n": "Västernorrland"
    }, {
        "c": "U",
        "n": "Västmanland"
    }, {
        "c": "O",
        "n": "Västra Götaland"
    }, {
        "c": "T",
        "n": "Örebro"
    }, {
        "c": "E",
        "n": "Östergötland"
    }],
    "SO": [{
        "c": "AW",
        "n": "Awdal"
    }, {
        "c": "BK",
        "n": "Bakool"
    }, {
        "c": "BN",
        "n": "Banaadir"
    }, {
        "c": "BR",
        "n": "Bari"
    }, {
        "c": "BY",
        "n": "Bay"
    }, {
        "c": "GA",
        "n": "Galguduud"
    }, {
        "c": "GE",
        "n": "Gedo"
    }, {
        "c": "HI",
        "n": "Hiiraan"
    }, {
        "c": "JD",
        "n": "Jubbada Dhexe"
    }, {
        "c": "JH",
        "n": "Jubbada Hoose"
    }, {
        "c": "MU",
        "n": "Mudug"
    }, {
        "c": "NU",
        "n": "Nugaal"
    }, {
        "c": "SA",
        "n": "Sanaag"
    }, {
        "c": "SD",
        "n": "Shabeellaha Dhexe"
    }, {
        "c": "SH",
        "n": "Shabeellaha Hoose"
    }, {
        "c": "SO",
        "n": "Sool"
    }, {
        "c": "TO",
        "n": "Togdheer"
    }, {
        "c": "WO",
        "n": "Woqooyi Galbeed"
    }],
    "SV": [{
        "c": "AH",
        "n": "Ahuachapán"
    }, {
        "c": "CA",
        "n": "Cabañas"
    }, {
        "c": "CH",
        "n": "Chalatenango"
    }, {
        "c": "CU",
        "n": "Cuscatlán"
    }, {
        "c": "LI",
        "n": "La Libertad"
    }, {
        "c": "PA",
        "n": "La Paz"
    }, {
        "c": "UN",
        "n": "La Unión"
    }, {
        "c": "MO",
        "n": "Morazán"
    }, {
        "c": "SM",
        "n": "San Miguel"
    }, {
        "c": "SS",
        "n": "San Salvador"
    }, {
        "c": "SV",
        "n": "San Vicente"
    }, {
        "c": "SA",
        "n": "Santa Ana"
    }, {
        "c": "SO",
        "n": "Sonsonate"
    }, {
        "c": "US",
        "n": "Usulután"
    }],
    "TH": [{
        "c": "S",
        "n": "Phatthaya"
    }, {
        "c": "10",
        "n": "Bangkok"
    }, {
        "c": "15",
        "n": "Ang Thong"
    }, {
        "c": "38",
        "n": "Bueng Kan"
    }, {
        "c": "31",
        "n": "Buri Ram"
    }, {
        "c": "24",
        "n": "Chachoengsao"
    }, {
        "c": "18",
        "n": "Chai Nat"
    }, {
        "c": "37",
        "n": "Amnat Charoen"
    }, {
        "c": "36",
        "n": "Chaiyaphum"
    }, {
        "c": "22",
        "n": "Chanthaburi"
    }, {
        "c": "50",
        "n": "Chiang Mai"
    }, {
        "c": "57",
        "n": "Chiang Rai"
    }, {
        "c": "20",
        "n": "Chon Buri"
    }, {
        "c": "86",
        "n": "Chumphon"
    }, {
        "c": "46",
        "n": "Kalasin"
    }, {
        "c": "62",
        "n": "Kamphaeng Phet"
    }, {
        "c": "71",
        "n": "Kanchanaburi"
    }, {
        "c": "40",
        "n": "Khon Kaen"
    }, {
        "c": "81",
        "n": "Krabi"
    }, {
        "c": "52",
        "n": "Lampang"
    }, {
        "c": "51",
        "n": "Lamphun"
    }, {
        "c": "42",
        "n": "Loei"
    }, {
        "c": "16",
        "n": "Lop Buri"
    }, {
        "c": "58",
        "n": "Mae Hong Son"
    }, {
        "c": "44",
        "n": "Maha Sarakham"
    }, {
        "c": "49",
        "n": "Mukdahan"
    }, {
        "c": "26",
        "n": "Nakhon Nayok"
    }, {
        "c": "73",
        "n": "Nakhon Pathom"
    }, {
        "c": "48",
        "n": "Nakhon Phanom"
    }, {
        "c": "30",
        "n": "Nakhon Ratchasima"
    }, {
        "c": "60",
        "n": "Nakhon Sawan"
    }, {
        "c": "80",
        "n": "Nakhon Si Thammarat"
    }, {
        "c": "55",
        "n": "Nan"
    }, {
        "c": "96",
        "n": "Narathiwat"
    }, {
        "c": "39",
        "n": "Nong Bua Lam Phu"
    }, {
        "c": "43",
        "n": "Nong Khai"
    }, {
        "c": "12",
        "n": "Nonthaburi"
    }, {
        "c": "13",
        "n": "Pathum Thani"
    }, {
        "c": "94",
        "n": "Pattani"
    }, {
        "c": "82",
        "n": "Phangnga"
    }, {
        "c": "93",
        "n": "Phatthalung"
    }, {
        "c": "56",
        "n": "Phayao"
    }, {
        "c": "67",
        "n": "Phetchabun"
    }, {
        "c": "76",
        "n": "Phetchaburi"
    }, {
        "c": "66",
        "n": "Phichit"
    }, {
        "c": "65",
        "n": "Phitsanulok"
    }, {
        "c": "54",
        "n": "Phrae"
    }, {
        "c": "14",
        "n": "Phra Nakhon Si Ayutthaya"
    }, {
        "c": "83",
        "n": "Phuket"
    }, {
        "c": "25",
        "n": "Prachin Buri"
    }, {
        "c": "77",
        "n": "Prachuap Khiri Khan"
    }, {
        "c": "85",
        "n": "Ranong"
    }, {
        "c": "70",
        "n": "Ratchaburi"
    }, {
        "c": "21",
        "n": "Rayong"
    }, {
        "c": "45",
        "n": "Roi Et"
    }, {
        "c": "27",
        "n": "Sa Kaeo"
    }, {
        "c": "47",
        "n": "Sakon Nakhon"
    }, {
        "c": "11",
        "n": "Samut Prakan"
    }, {
        "c": "74",
        "n": "Samut Sakhon"
    }, {
        "c": "75",
        "n": "Samut Songkhram"
    }, {
        "c": "19",
        "n": "Saraburi"
    }, {
        "c": "91",
        "n": "Satun"
    }, {
        "c": "17",
        "n": "Sing Buri"
    }, {
        "c": "33",
        "n": "Si Sa Ket"
    }, {
        "c": "90",
        "n": "Songkhla"
    }, {
        "c": "64",
        "n": "Sukhothai"
    }, {
        "c": "72",
        "n": "Suphan Buri"
    }, {
        "c": "84",
        "n": "Surat Thani"
    }, {
        "c": "32",
        "n": "Surin"
    }, {
        "c": "63",
        "n": "Tak"
    }, {
        "c": "92",
        "n": "Trang"
    }, {
        "c": "23",
        "n": "Trat"
    }, {
        "c": "34",
        "n": "Ubon Ratchathani"
    }, {
        "c": "41",
        "n": "Udon Thani"
    }, {
        "c": "61",
        "n": "Uthai Thani"
    }, {
        "c": "53",
        "n": "Uttaradit"
    }, {
        "c": "95",
        "n": "Yala"
    }, {
        "c": "35",
        "n": "Yasothon"
    }],
    "TR": [{
        "c": "01",
        "n": "Adana"
    }, {
        "c": "02",
        "n": "Adıyaman"
    }, {
        "c": "03",
        "n": "Afyonkarahisar"
    }, {
        "c": "04",
        "n": "Ağrı"
    }, {
        "c": "68",
        "n": "Aksaray"
    }, {
        "c": "05",
        "n": "Amasya"
    }, {
        "c": "06",
        "n": "Ankara"
    }, {
        "c": "07",
        "n": "Antalya"
    }, {
        "c": "75",
        "n": "Ardahan"
    }, {
        "c": "08",
        "n": "Artvin"
    }, {
        "c": "09",
        "n": "Aydın"
    }, {
        "c": "10",
        "n": "Balıkesir"
    }, {
        "c": "74",
        "n": "Bartın"
    }, {
        "c": "72",
        "n": "Batman"
    }, {
        "c": "69",
        "n": "Bayburt"
    }, {
        "c": "11",
        "n": "Bilecik"
    }, {
        "c": "12",
        "n": "Bingöl"
    }, {
        "c": "13",
        "n": "Bitlis"
    }, {
        "c": "14",
        "n": "Bolu"
    }, {
        "c": "15",
        "n": "Burdur"
    }, {
        "c": "16",
        "n": "Bursa"
    }, {
        "c": "17",
        "n": "Çanakkale"
    }, {
        "c": "18",
        "n": "Çankırı"
    }, {
        "c": "19",
        "n": "Çorum"
    }, {
        "c": "20",
        "n": "Denizli"
    }, {
        "c": "21",
        "n": "Diyarbakır"
    }, {
        "c": "81",
        "n": "Düzce"
    }, {
        "c": "22",
        "n": "Edirne"
    }, {
        "c": "23",
        "n": "Elazığ"
    }, {
        "c": "24",
        "n": "Erzincan"
    }, {
        "c": "25",
        "n": "Erzurum"
    }, {
        "c": "26",
        "n": "Eskişehir"
    }, {
        "c": "27",
        "n": "Gaziantep"
    }, {
        "c": "28",
        "n": "Giresun"
    }, {
        "c": "29",
        "n": "Gümüşhane"
    }, {
        "c": "30",
        "n": "Hakkâri"
    }, {
        "c": "31",
        "n": "Hatay"
    }, {
        "c": "76",
        "n": "Iğdır"
    }, {
        "c": "32",
        "n": "Isparta"
    }, {
        "c": "34",
        "n": "İstanbul"
    }, {
        "c": "35",
        "n": "İzmir"
    }, {
        "c": "46",
        "n": "Kahramanmaraş"
    }, {
        "c": "78",
        "n": "Karabük"
    }, {
        "c": "70",
        "n": "Karaman"
    }, {
        "c": "36",
        "n": "Kars"
    }, {
        "c": "37",
        "n": "Kastamonu"
    }, {
        "c": "38",
        "n": "Kayseri"
    }, {
        "c": "71",
        "n": "Kırıkkale"
    }, {
        "c": "39",
        "n": "Kırklareli"
    }, {
        "c": "40",
        "n": "Kırşehir"
    }, {
        "c": "79",
        "n": "Kilis"
    }, {
        "c": "41",
        "n": "Kocaeli"
    }, {
        "c": "42",
        "n": "Konya"
    }, {
        "c": "43",
        "n": "Kütahya"
    }, {
        "c": "44",
        "n": "Malatya"
    }, {
        "c": "45",
        "n": "Manisa"
    }, {
        "c": "47",
        "n": "Mardin"
    }, {
        "c": "33",
        "n": "Mersin"
    }, {
        "c": "48",
        "n": "Muğla"
    }, {
        "c": "49",
        "n": "Muş"
    }, {
        "c": "50",
        "n": "Nevşehir"
    }, {
        "c": "51",
        "n": "Niğde"
    }, {
        "c": "52",
        "n": "Ordu"
    }, {
        "c": "80",
        "n": "Osmaniye"
    }, {
        "c": "53",
        "n": "Rize"
    }, {
        "c": "54",
        "n": "Sakarya"
    }, {
        "c": "55",
        "n": "Samsun"
    }, {
        "c": "56",
        "n": "Siirt"
    }, {
        "c": "57",
        "n": "Sinop"
    }, {
        "c": "58",
        "n": "Sivas"
    }, {
        "c": "63",
        "n": "Şanlıurfa"
    }, {
        "c": "73",
        "n": "Şırnak"
    }, {
        "c": "59",
        "n": "Tekirdağ"
    }, {
        "c": "60",
        "n": "Tokat"
    }, {
        "c": "61",
        "n": "Trabzon"
    }, {
        "c": "62",
        "n": "Tunceli"
    }, {
        "c": "64",
        "n": "Uşak"
    }, {
        "c": "65",
        "n": "Van"
    }, {
        "c": "77",
        "n": "Yalova"
    }, {
        "c": "66",
        "n": "Yozgat"
    }, {
        "c": "67",
        "n": "Zonguldak"
    }],
    "TT": [{
        "c": "CTT",
        "n": "Couva–Tabaquite–Talparo"
    }, {
        "c": "DMN",
        "n": "Diego Martin"
    }, {
        "c": "MRC",
        "n": "Mayaro-Rio Claro"
    }, {
        "c": "PED",
        "n": "Penal-Debe"
    }, {
        "c": "PRT",
        "n": "Princes Town"
    }, {
        "c": "SJL",
        "n": "San Juan-Laventille"
    }, {
        "c": "SGE",
        "n": "Sangre Grande"
    }, {
        "c": "SIP",
        "n": "Siparia"
    }, {
        "c": "TUP",
        "n": "Tunapuna-Piarco"
    }, {
        "c": "ARI",
        "n": "Arima"
    }, {
        "c": "CHA",
        "n": "Chaguanas"
    }, {
        "c": "PTF",
        "n": "Point Fortin"
    }, {
        "c": "POS",
        "n": "Port of Spain"
    }, {
        "c": "SFO",
        "n": "San Fernando"
    }, {
        "c": "TOB",
        "n": "Tobago"
    }],
    "TW": [{
        "c": "CHA",
        "n": "Changhua"
    }, {
        "c": "CYI",
        "n": "Chiayi City"
    }, {
        "c": "CYQ",
        "n": "Chiayi"
    }, {
        "c": "HSQ",
        "n": "Hsinchu"
    }, {
        "c": "HSZ",
        "n": "Hsinchu City"
    }, {
        "c": "HUA",
        "n": "Hualien"
    }, {
        "c": "ILA",
        "n": "Yilan"
    }, {
        "c": "KEE",
        "n": "Keelung"
    }, {
        "c": "KHH",
        "n": "Kaohsiung"
    }, {
        "c": "KIN",
        "n": "Kinmen"
    }, {
        "c": "LIE",
        "n": "Lienchiang"
    }, {
        "c": "MIA",
        "n": "Miaoli"
    }, {
        "c": "NAN",
        "n": "Nantou"
    }, {
        "c": "NWT",
        "n": "New Taipei"
    }, {
        "c": "PEN",
        "n": "Penghu"
    }, {
        "c": "PIF",
        "n": "Pingtung"
    }, {
        "c": "TAO",
        "n": "Taoyuan"
    }, {
        "c": "TNN",
        "n": "Tainan"
    }, {
        "c": "TPE",
        "n": "Taipei"
    }, {
        "c": "TTT",
        "n": "Taitung"
    }, {
        "c": "TXG",
        "n": "Taichung"
    }, {
        "c": "YUN",
        "n": "Yunlin"
    }],
    "UA": [{
        "c": "21",
        "n": "Vinnytska oblast"
    }, {
        "c": "43",
        "n": "Volynska oblast"
    }, {
        "c": "49",
        "n": "Dnipropetrovska oblast"
    }, {
        "c": "10",
        "n": "Zhytomyrska oblast"
    }, {
        "c": "88",
        "n": "Zakarpatska oblast"
    }, {
        "c": "76",
        "n": "Ivano-Frankivska oblast"
    }, {
        "c": "07",
        "n": "Kyivska oblast"
    }, {
        "c": "25",
        "n": "Kirovohradska oblast"
    }, {
        "c": "79",
        "n": "Lvivska oblast"
    }, {
        "c": "54",
        "n": "Mykolaivska oblast"
    }, {
        "c": "65",
        "n": "Odeska oblast"
    }, {
        "c": "36",
        "n": "Poltavska oblast"
    }, {
        "c": "33",
        "n": "Rivnenska oblast"
    }, {
        "c": "40",
        "n": "Sumska oblast"
    }, {
        "c": "46",
        "n": "Ternopilska oblast"
    }, {
        "c": "61",
        "n": "Kharkivska oblast"
    }, {
        "c": "29",
        "n": "Khmelnytska oblast"
    }, {
        "c": "18",
        "n": "Cherkaska oblast"
    }, {
        "c": "14",
        "n": "Chernihivska oblast"
    }, {
        "c": "58",
        "n": "Chernivetska oblast"
    }, {
        "c": "01",
        "n": "Kyiv city"
    }],
    "UG": [{
        "c": "1",
        "n": "Abim"
    }, {
        "c": "2",
        "n": "Adjumani"
    }, {
        "c": "3",
        "n": "Amolatar"
    }, {
        "c": "4",
        "n": "Amuria"
    }, {
        "c": "5",
        "n": "Apac"
    }, {
        "c": "6",
        "n": "Arua"
    }, {
        "c": "7",
        "n": "Budaka"
    }, {
        "c": "8",
        "n": "Bugiri"
    }, {
        "c": "9",
        "n": "Bukwa"
    }, {
        "c": "10",
        "n": "Buliisa"
    }, {
        "c": "11",
        "n": "Bundibugyo"
    }, {
        "c": "12",
        "n": "Bushenyi"
    }, {
        "c": "13",
        "n": "Busia"
    }, {
        "c": "14",
        "n": "Namutumba"
    }, {
        "c": "15",
        "n": "Butaleja"
    }, {
        "c": "16",
        "n": "Dokolo"
    }, {
        "c": "17",
        "n": "Gulu"
    }, {
        "c": "18",
        "n": "Hoima"
    }, {
        "c": "19",
        "n": "Ibanda"
    }, {
        "c": "20",
        "n": "Iganga"
    }, {
        "c": "21",
        "n": "Jinja"
    }, {
        "c": "22",
        "n": "Kaabong"
    }, {
        "c": "23",
        "n": "Kabale"
    }, {
        "c": "24",
        "n": "Kabarole"
    }, {
        "c": "25",
        "n": "Kaberamaido"
    }, {
        "c": "26",
        "n": "Isingiro"
    }, {
        "c": "27",
        "n": "Kalangala"
    }, {
        "c": "28",
        "n": "Kaliro"
    }, {
        "c": "29",
        "n": "Kampala"
    }, {
        "c": "30",
        "n": "Kamuli"
    }, {
        "c": "31",
        "n": "Kamwenge"
    }, {
        "c": "32",
        "n": "Kanungu"
    }, {
        "c": "33",
        "n": "Kapchorwa"
    }, {
        "c": "34",
        "n": "Kasese"
    }, {
        "c": "35",
        "n": "Katakwi"
    }, {
        "c": "36",
        "n": "Kayunga"
    }, {
        "c": "37",
        "n": "Kibaale"
    }, {
        "c": "38",
        "n": "Kiboga"
    }, {
        "c": "39",
        "n": "Amuru"
    }, {
        "c": "40",
        "n": "Kiruhura"
    }, {
        "c": "41",
        "n": "Kisoro"
    }, {
        "c": "42",
        "n": "Kitgum"
    }, {
        "c": "43",
        "n": "Koboko"
    }, {
        "c": "44",
        "n": "Kotido"
    }, {
        "c": "45",
        "n": "Kumi"
    }, {
        "c": "46",
        "n": "Kyenjojo"
    }, {
        "c": "47",
        "n": "Lira"
    }, {
        "c": "48",
        "n": "Luweero"
    }, {
        "c": "49",
        "n": "Bududa"
    }, {
        "c": "50",
        "n": "Maracha"
    }, {
        "c": "51",
        "n": "Masaka"
    }, {
        "c": "52",
        "n": "Masindi"
    }, {
        "c": "53",
        "n": "Mayuge"
    }, {
        "c": "54",
        "n": "Mbale"
    }, {
        "c": "55",
        "n": "Mbarara"
    }, {
        "c": "56",
        "n": "Mityana"
    }, {
        "c": "57",
        "n": "Moroto"
    }, {
        "c": "58",
        "n": "Moyo"
    }, {
        "c": "59",
        "n": "Mpigi"
    }, {
        "c": "60",
        "n": "Mubende"
    }, {
        "c": "61",
        "n": "Mukono"
    }, {
        "c": "62",
        "n": "Nakapiripirit"
    }, {
        "c": "63",
        "n": "Nakaseke"
    }, {
        "c": "64",
        "n": "Nakasongola"
    }, {
        "c": "65",
        "n": "Nebbi"
    }, {
        "c": "66",
        "n": "Ntungamo"
    }, {
        "c": "67",
        "n": "Oyam"
    }, {
        "c": "68",
        "n": "Pader"
    }, {
        "c": "69",
        "n": "Pallisa"
    }, {
        "c": "70",
        "n": "Rakai"
    }, {
        "c": "71",
        "n": "Rukungiri"
    }, {
        "c": "72",
        "n": "Ssembabule"
    }, {
        "c": "73",
        "n": "Sironko"
    }, {
        "c": "74",
        "n": "Soroti"
    }, {
        "c": "75",
        "n": "Tororo"
    }, {
        "c": "76",
        "n": "Wakiso"
    }, {
        "c": "77",
        "n": "Yumbe"
    }, {
        "c": "78",
        "n": "Agago"
    }, {
        "c": "79",
        "n": "Alebtong"
    }, {
        "c": "80",
        "n": "Amudat"
    }, {
        "c": "81",
        "n": "Buhweju"
    }, {
        "c": "82",
        "n": "Buikwe"
    }, {
        "c": "83",
        "n": "Bukedea"
    }, {
        "c": "84",
        "n": "Bukomansimbi"
    }, {
        "c": "85",
        "n": "Bulambuli"
    }, {
        "c": "86",
        "n": "Butambala"
    }, {
        "c": "87",
        "n": "Buvuma"
    }, {
        "c": "88",
        "n": "Buyende"
    }, {
        "c": "89",
        "n": "Gomba"
    }, {
        "c": "90",
        "n": "Kalungu"
    }, {
        "c": "91",
        "n": "Kibuku"
    }, {
        "c": "92",
        "n": "Kiryandongo"
    }, {
        "c": "93",
        "n": "Kole"
    }, {
        "c": "94",
        "n": "Kween"
    }, {
        "c": "95",
        "n": "Kyankwanzi"
    }, {
        "c": "96",
        "n": "Kyegegwa"
    }, {
        "c": "97",
        "n": "Lamwo"
    }, {
        "c": "98",
        "n": "Luuka"
    }, {
        "c": "99",
        "n": "Lwengo"
    }, {
        "c": "100",
        "n": "Lyantonde"
    }, {
        "c": "101",
        "n": "Manafwa"
    }, {
        "c": "102",
        "n": "Mitooma"
    }, {
        "c": "103",
        "n": "Namayingo"
    }, {
        "c": "104",
        "n": "Napak"
    }, {
        "c": "105",
        "n": "Ngora"
    }, {
        "c": "106",
        "n": "Ntoroko"
    }, {
        "c": "107",
        "n": "Nwoya"
    }, {
        "c": "108",
        "n": "Otuke"
    }, {
        "c": "109",
        "n": "Rubirizi"
    }, {
        "c": "110",
        "n": "Serere"
    }, {
        "c": "111",
        "n": "Sheema"
    }, {
        "c": "112",
        "n": "Zombo"
    }],
    "US": [{
        "c": "AL",
        "n": "Alabama"
    }, {
        "c": "AK",
        "n": "Alaska"
    }, {
        "c": "AZ",
        "n": "Arizona"
    }, {
        "c": "AR",
        "n": "Arkansas"
    }, {
        "c": "CA",
        "n": "California"
    }, {
        "c": "CO",
        "n": "Colorado"
    }, {
        "c": "CT",
        "n": "Connecticut"
    }, {
        "c": "DE",
        "n": "Delaware"
    }, {
        "c": "DC",
        "n": "District of Columbia"
    }, {
        "c": "FL",
        "n": "Florida"
    }, {
        "c": "GA",
        "n": "Georgia"
    }, {
        "c": "GU",
        "n": "Guam"
    }, {
        "c": "HI",
        "n": "Hawaii"
    }, {
        "c": "ID",
        "n": "Idaho"
    }, {
        "c": "IL",
        "n": "Illinois"
    }, {
        "c": "IN",
        "n": "Indiana"
    }, {
        "c": "IA",
        "n": "Iowa"
    }, {
        "c": "KS",
        "n": "Kansas"
    }, {
        "c": "KY",
        "n": "Kentucky"
    }, {
        "c": "LA",
        "n": "Louisiana"
    }, {
        "c": "ME",
        "n": "Maine"
    }, {
        "c": "MD",
        "n": "Maryland"
    }, {
        "c": "MA",
        "n": "Massachusetts"
    }, {
        "c": "MI",
        "n": "Michigan"
    }, {
        "c": "MN",
        "n": "Minnesota"
    }, {
        "c": "MS",
        "n": "Mississippi"
    }, {
        "c": "MO",
        "n": "Missouri"
    }, {
        "c": "MT",
        "n": "Montana"
    }, {
        "c": "NE",
        "n": "Nebraska"
    }, {
        "c": "NV",
        "n": "Nevada"
    }, {
        "c": "NH",
        "n": "New Hampshire"
    }, {
        "c": "NJ",
        "n": "New Jersey"
    }, {
        "c": "NM",
        "n": "New Mexico"
    }, {
        "c": "NY",
        "n": "New York"
    }, {
        "c": "NC",
        "n": "North Carolina"
    }, {
        "c": "ND",
        "n": "North Dakota"
    }, {
        "c": "OH",
        "n": "Ohio"
    }, {
        "c": "OK",
        "n": "Oklahoma"
    }, {
        "c": "OR",
        "n": "Oregon"
    }, {
        "c": "PA",
        "n": "Pennsylvania"
    }, {
        "c": "PR",
        "n": "Puerto Rico"
    }, {
        "c": "RI",
        "n": "Rhode Island"
    }, {
        "c": "SC",
        "n": "South Carolina"
    }, {
        "c": "SD",
        "n": "South Dakota"
    }, {
        "c": "TN",
        "n": "Tennessee"
    }, {
        "c": "TX",
        "n": "Texas"
    }, {
        "c": "UT",
        "n": "Utah"
    }, {
        "c": "VT",
        "n": "Vermont"
    }, {
        "c": "VI",
        "n": "Virgin Islands"
    }, {
        "c": "VA",
        "n": "Virginia"
    }, {
        "c": "WA",
        "n": "Washington"
    }, {
        "c": "WV",
        "n": "West Virginia"
    }, {
        "c": "WI",
        "n": "Wisconsin"
    }, {
        "c": "WY",
        "n": "Wyoming"
    }, {
        "c": "AA",
        "n": "Armed Forces - Americas"
    }, {
        "c": "AE",
        "n": "Armed Forces - Europe"
    }, {
        "c": "AP",
        "n": "Armed Forces - Pacific"
    }],
    "UY": [{
        "c": "AR",
        "n": "Artigas"
    }, {
        "c": "CA",
        "n": "Canelones"
    }, {
        "c": "CL",
        "n": "Cerro Largo"
    }, {
        "c": "CO",
        "n": "Colonia"
    }, {
        "c": "DU",
        "n": "Durazno"
    }, {
        "c": "FS",
        "n": "Flores"
    }, {
        "c": "FD",
        "n": "Florida"
    }, {
        "c": "LA",
        "n": "Lavalleja"
    }, {
        "c": "MA",
        "n": "Maldonado"
    }, {
        "c": "MO",
        "n": "Montevideo"
    }, {
        "c": "PA",
        "n": "Paysandú"
    }, {
        "c": "RN",
        "n": "Río Negro"
    }, {
        "c": "RV",
        "n": "Rivera"
    }, {
        "c": "RO",
        "n": "Rocha"
    }, {
        "c": "SA",
        "n": "Salto"
    }, {
        "c": "SJ",
        "n": "San José"
    }, {
        "c": "SO",
        "n": "Soriano"
    }, {
        "c": "TA",
        "n": "Tacuarembó"
    }, {
        "c": "TT",
        "n": "Treinta y Tres"
    }],
    "UZ": [{
        "c": "TK",
        "n": "Toshkent",
        "useAsCityName": true
    }, {
        "c": "TO",
        "n": "Toshkent"
    }, {
        "c": "AN",
        "n": "Andijon"
    }, {
        "c": "BU",
        "n": "Buxoro"
    }, {
        "c": "FA",
        "n": "Farg\u0027ona"
    }, {
        "c": "JI",
        "n": "Jizzax"
    }, {
        "c": "NG",
        "n": "Namangan"
    }, {
        "c": "NW",
        "n": "Navoiy"
    }, {
        "c": "QA",
        "n": "Qashqadaryo"
    }, {
        "c": "SA",
        "n": "Samarqand"
    }, {
        "c": "SI",
        "n": "Sidaryo"
    }, {
        "c": "SU",
        "n": "Surxondaryo"
    }, {
        "c": "XO",
        "n": "Xorazm"
    }, {
        "c": "QR",
        "n": "Qoraqalpog‘iston Respublikasi"
    }],
    "VE": [{
        "c": "W",
        "n": "Dependencias Federales"
    }, {
        "c": "A",
        "n": "Distrito Federal"
    }, {
        "c": "Z",
        "n": "Amazonas"
    }, {
        "c": "B",
        "n": "Anzoátegui"
    }, {
        "c": "C",
        "n": "Apure"
    }, {
        "c": "D",
        "n": "Aragua"
    }, {
        "c": "E",
        "n": "Barinas"
    }, {
        "c": "F",
        "n": "Bolívar"
    }, {
        "c": "G",
        "n": "Carabobo"
    }, {
        "c": "H",
        "n": "Cojedes"
    }, {
        "c": "Y",
        "n": "Delta Amacuro"
    }, {
        "c": "I",
        "n": "Falcón"
    }, {
        "c": "J",
        "n": "Guárico"
    }, {
        "c": "K",
        "n": "Lara"
    }, {
        "c": "L",
        "n": "Mérida"
    }, {
        "c": "M",
        "n": "Miranda"
    }, {
        "c": "N",
        "n": "Monagas"
    }, {
        "c": "O",
        "n": "Nueva Esparta"
    }, {
        "c": "P",
        "n": "Portuguesa"
    }, {
        "c": "R",
        "n": "Sucre"
    }, {
        "c": "S",
        "n": "Táchira"
    }, {
        "c": "T",
        "n": "Trujillo"
    }, {
        "c": "X",
        "n": "Vargas"
    }, {
        "c": "U",
        "n": "Yaracuy"
    }, {
        "c": "V",
        "n": "Zulia"
    }],
    "VN": [{
        "c": "44",
        "n": "An Giang"
    }, {
        "c": "43",
        "n": "Ba Ria-Vung Tau"
    }, {
        "c": "54",
        "n": "Bac Giang"
    }, {
        "c": "53",
        "n": "Bac Kan"
    }, {
        "c": "55",
        "n": "Bac Lieu"
    }, {
        "c": "56",
        "n": "Bac Ninh"
    }, {
        "c": "50",
        "n": "Ben Tre"
    }, {
        "c": "31",
        "n": "Binh Dinh"
    }, {
        "c": "57",
        "n": "Binh Duong"
    }, {
        "c": "58",
        "n": "Binh Phuoc"
    }, {
        "c": "40",
        "n": "Binh Thuan"
    }, {
        "c": "59",
        "n": "Ca Mau"
    }, {
        "c": "04",
        "n": "Cao Bang"
    }, {
        "c": "33",
        "n": "Dak Lak"
    }, {
        "c": "72",
        "n": "Dak Nong"
    }, {
        "c": "71",
        "n": "Dak Bien"
    }, {
        "c": "39",
        "n": "Dong Nai"
    }, {
        "c": "45",
        "n": "Dong Thap"
    }, {
        "c": "30",
        "n": "Gia Lai"
    }, {
        "c": "03",
        "n": "Ha Giang"
    }, {
        "c": "63",
        "n": "Ha Nam"
    }, {
        "c": "23",
        "n": "Ha Tinh"
    }, {
        "c": "61",
        "n": "Hai Duong"
    }, {
        "c": "73",
        "n": "Hau Giang"
    }, {
        "c": "14",
        "n": "Hoa Binh"
    }, {
        "c": "66",
        "n": "Hung Yen"
    }, {
        "c": "34",
        "n": "Khanh Hoa"
    }, {
        "c": "47",
        "n": "Kien Giang"
    }, {
        "c": "28",
        "n": "Kon Tum"
    }, {
        "c": "01",
        "n": "Lai Chau"
    }, {
        "c": "35",
        "n": "Lam Dong"
    }, {
        "c": "09",
        "n": "Lang Son"
    }, {
        "c": "02",
        "n": "Lao Cai"
    }, {
        "c": "41",
        "n": "Long An"
    }, {
        "c": "67",
        "n": "Nam Dinh"
    }, {
        "c": "22",
        "n": "Nghe An"
    }, {
        "c": "18",
        "n": "Ninh Binh"
    }, {
        "c": "36",
        "n": "Ninh Thuan"
    }, {
        "c": "68",
        "n": "Phu Tho"
    }, {
        "c": "32",
        "n": "Phu Yen"
    }, {
        "c": "24",
        "n": "Quang Binh"
    }, {
        "c": "27",
        "n": "Quang Nam"
    }, {
        "c": "29",
        "n": "Quang Ngai"
    }, {
        "c": "13",
        "n": "Quang Ninh"
    }, {
        "c": "25",
        "n": "Quan Tri"
    }, {
        "c": "52",
        "n": "Soc Trang"
    }, {
        "c": "05",
        "n": "Son La"
    }, {
        "c": "37",
        "n": "Tay Ninh"
    }, {
        "c": "20",
        "n": "Thai Binh"
    }, {
        "c": "69",
        "n": "Thai Nguyen"
    }, {
        "c": "21",
        "n": "Thanh Hoa"
    }, {
        "c": "26",
        "n": "Thua Thien-Hue"
    }, {
        "c": "46",
        "n": "Tien Giang"
    }, {
        "c": "51",
        "n": "Tra Vinh"
    }, {
        "c": "07",
        "n": "Tuyen Quang"
    }, {
        "c": "49",
        "n": "Vinh Long"
    }, {
        "c": "70",
        "n": "Vinh Phuc"
    }, {
        "c": "06",
        "n": "Yen Bai"
    }, {
        "c": "CT",
        "n": "Can Tho"
    }, {
        "c": "DN",
        "n": "Da Nang"
    }, {
        "c": "HN",
        "n": "Hanoi"
    }, {
        "c": "HP",
        "n": "Hai Phong"
    }, {
        "c": "SG",
        "n": "Ho Chi Minh"
    }],
    "XK": [{
        "c": "01",
        "n": "Pristina"
    }, {
        "c": "02",
        "n": "Mitrovica"
    }, {
        "c": "03",
        "n": "Peja (Pecki)"
    }, {
        "c": "04",
        "n": "Prizren"
    }, {
        "c": "05",
        "n": "Ferizaj"
    }, {
        "c": "06",
        "n": "Gjilan"
    }, {
        "c": "07",
        "n": "Gjakova"
    }],
    "ZA": [{
        "c": "EC",
        "n": "Eastern Cape"
    }, {
        "c": "FS",
        "n": "Free State"
    }, {
        "c": "GP",
        "n": "Gauteng"
    }, {
        "c": "ZN",
        "n": "KwaZulu-Natal"
    }, {
        "c": "LP",
        "n": "Limpopo"
    }, {
        "c": "MP",
        "n": "Mpumalanga"
    }, {
        "c": "NW",
        "n": "North West"
    }, {
        "c": "NC",
        "n": "Northern Cape"
    }, {
        "c": "WC",
        "n": "Western Cape"
    }]
});