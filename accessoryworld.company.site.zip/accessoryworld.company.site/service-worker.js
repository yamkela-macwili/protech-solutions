"use strict";

importScripts('https://storage.googleapis.com/workbox-cdn/releases/4.3.1/workbox-sw.js');

workbox.loadModule('workbox-strategies');

RegExp.escape = function(string) {
    return string.replace(/[-\/\\^$*+?.()|[\]{}]/g, '\\$&')
};

var storeId = 88112793;
var cachePrefix = 'starter-site: ';
var regExpRoutes = {
    home_page: '/\/(\?lang=.*\&from_admin)?$/',
    network_first: '/.*' + RegExp.escape('script.js?' + storeId) + '.*$/',
    stale_while_revalidate: '/.*(?:' + [
        'd3cy3u1txmkqs3.cloudfront.net',
        'd3cy3u1txmkqs3.cloudfront.net',
        'd34ikvsdm2rlij.cloudfront.net',
        'd3cy3u1txmkqs3.cloudfront.net',
        'categories.js?ownerid=' + storeId,
        'd1oxsl77a1kjht.cloudfront.net',
        'data.js?ownerid=' + storeId,
        'https://d20ubqycd8ynev.cloudfront.net/storefront-app.js',
        'ecomm.events/i.js',
        'analytics.sitewit.com/ecwid.plugin.js',
        'storage.googleapis.com/goostav-static-files/rh-easy-ecwid.js',
        'd35z3p2poghz10.cloudfront.net/apps/ecwid-shop-at-app/shopatapp.css',
        'd35z3p2poghz10.cloudfront.net/apps/ecwid-shop-at-app/bundle',
        'd1howb1wwyap5o.cloudfront.net/ym/ecwid_ym.js',
        'ya-metrika-ec.ecwid-labs.com/storefront/index.js'
    ].filter(Boolean).map(function(item) {
        return RegExp.escape(item);
    }).join('|') + ').*$/',
    images_cache: '/.*(?:png|gif|jpg|svg)$/',
    fonts_cache: '/.*(?:ttf|woff|woff2)$/'
};

var customFilter = {
    requestWillFetch: async function requestWillFetch(event) {
        var request = event.request;
        if (request.cache === 'only-if-cached' && request.mode !== 'same-origin') {
            return;
        }
        return request;
    }
};

workbox.navigationPreload.enable();

workbox.routing.registerRoute(
    regExpRoutes.home_page,
    new workbox.strategies.NetworkFirst({
        cacheName: cachePrefix + 'home-page',
        plugins: [
            customFilter,
            new workbox.expiration.Plugin({
                maxAgeSeconds: 60 * 60 * 24 * 30
            })
        ]
    })
);

var customStrategy = new workbox.strategies.NetworkFirst({
    plugins: [customFilter]
});

workbox.routing.registerRoute(/\/.+$/, customStrategy);

workbox.routing.registerRoute(
    regExpRoutes.network_first,
    new workbox.strategies.NetworkFirst({
        cacheName: cachePrefix + 'network_first',
        plugins: [
            new workbox.expiration.Plugin({
                maxAgeSeconds: 60 * 60 * 24 * 30
            })
        ]
    })
);

workbox.routing.registerRoute(
    regExpRoutes.stale_while_revalidate,
    new workbox.strategies.StaleWhileRevalidate({
        cacheName: cachePrefix + 'stale-while-revalidate',
        plugins: [
            new workbox.expiration.Plugin({
                maxAgeSeconds: 60 * 60 * 24 * 30
            })
        ]
    })
);

workbox.routing.registerRoute(
    regExpRoutes.images_cache,
    new workbox.strategies.StaleWhileRevalidate({
        cacheName: cachePrefix + 'images-cache',
        plugins: [
            new workbox.expiration.Plugin({
                maxAgeSeconds: 60 * 60 * 24 * 30,
                maxEntries: 100,
                purgeOnQuotaError: true
            })
        ]
    })
);

workbox.routing.registerRoute(
    regExpRoutes.fonts_cache,
    new workbox.strategies.StaleWhileRevalidate({
        cacheName: cachePrefix + 'fonts-cache',
        plugins: [
            new workbox.expiration.Plugin({
                maxAgeSeconds: 60 * 60 * 24 * 365
            })
        ]
    })
);

self.addEventListener('fetch', function(event) {
    if (event.request.url.match('^.*(\/edit\/).*$')) {
        return false;
    }
    event.respondWith(
        caches.match(event.request).then(function(response) {
            return response || fetch(event.request);
        })
    );
});